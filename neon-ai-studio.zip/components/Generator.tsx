import React, { useState, useEffect, useMemo } from 'react';
import { Download, Loader2, Sparkles, RefreshCw, Wand2, Image as ImageIcon, Maximize2, Layers, Clock } from 'lucide-react';
import { GenerationSettings, GeneratedImage } from '../types';
import { STYLE_OPTIONS, ASPECT_RATIOS } from '../constants';
import { generateImage } from '../services/geminiService';

const Generator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedImages, setGeneratedImages] = useState<GeneratedImage[]>([]);
  
  // Initialize settings from local storage or default
  const [settings, setSettings] = useState<GenerationSettings>(() => {
    const saved = localStorage.getItem('lumina_settings');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Failed to parse saved settings", e);
      }
    }
    return {
      style: 'realistic',
      aspectRatio: '1:1',
      quality: 'standard'
    };
  });

  // Load history from local storage
  useEffect(() => {
    const saved = localStorage.getItem('lumina_history');
    if (saved) {
      try {
        setGeneratedImages(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse history");
      }
    }
  }, []);

  // Save history to local storage
  useEffect(() => {
    localStorage.setItem('lumina_history', JSON.stringify(generatedImages));
  }, [generatedImages]);

  // Save settings to local storage
  useEffect(() => {
    localStorage.setItem('lumina_settings', JSON.stringify(settings));
  }, [settings]);

  // Derive unique recent prompts from history
  const recentPrompts = useMemo(() => {
    return Array.from(new Set(generatedImages.map(img => img.prompt))).slice(0, 10);
  }, [generatedImages]);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    setError(null);

    try {
      const base64Image = await generateImage(prompt, settings);
      
      const newImage: GeneratedImage = {
        id: Date.now().toString(),
        url: base64Image,
        prompt: prompt,
        style: settings.style,
        aspectRatio: settings.aspectRatio,
        timestamp: Date.now(),
        model: settings.quality === 'hd' ? 'Pro' : 'Fast'
      };

      setGeneratedImages(prev => [newImage, ...prev]);
    } catch (err: any) {
      setError(err.message || "Failed to generate image. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = (image: GeneratedImage) => {
    const link = document.createElement('a');
    link.href = image.url;
    link.download = `lumina-${image.id}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const currentImage = generatedImages[0];

  return (
    <div id="generator" className="py-24 relative z-10 px-6 max-w-7xl mx-auto">
      <div className="flex flex-col lg:flex-row gap-8">
        
        {/* Input Panel */}
        <div className="w-full lg:w-1/3 space-y-6">
          <div className="glass-panel p-6 rounded-2xl shadow-lg dark:shadow-none">
            <div className="flex items-center gap-2 mb-4 text-indigo-600 dark:text-indigo-300">
              <Wand2 className="w-5 h-5" />
              <h2 className="text-lg font-bold font-display">Create Image</h2>
            </div>
            
            <div className="space-y-4">
              {/* Prompt Input */}
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-gray-400 mb-2">Prompt</label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="A futuristic city with flying cars, neon lights, cyberpunk style..."
                  className="w-full bg-white dark:bg-black/40 border border-slate-200 dark:border-white/10 rounded-xl p-4 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[120px] resize-none transition-colors"
                />
              </div>

              {/* Prompt History */}
              {recentPrompts.length > 0 && (
                <div className="animate-in fade-in slide-in-from-top-2">
                  <div className="flex items-center gap-2 mb-2">
                     <Clock className="w-3 h-3 text-slate-400" />
                     <span className="text-xs font-medium text-slate-500 dark:text-gray-500 uppercase tracking-wider">Recent</span>
                  </div>
                  <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-slate-200 dark:scrollbar-thumb-white/10 mask-linear-fade">
                    {recentPrompts.map((p, i) => (
                      <button
                        key={i}
                        onClick={() => setPrompt(p)}
                        className="flex-shrink-0 text-xs max-w-[200px] truncate px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-gray-400 hover:bg-indigo-50 dark:hover:bg-white/10 hover:text-indigo-600 dark:hover:text-indigo-300 border border-slate-200 dark:border-white/5 transition-all text-left shadow-sm"
                        title={p}
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Style Selector */}
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-gray-400 mb-2">Style</label>
                <div className="grid grid-cols-2 gap-2">
                  {STYLE_OPTIONS.map((style) => (
                    <button
                      key={style.id}
                      onClick={() => setSettings({ ...settings, style: style.id })}
                      className={`text-sm px-3 py-2 rounded-lg text-left transition-all ${
                        settings.style === style.id
                          ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20'
                          : 'bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-gray-400 hover:bg-slate-200 dark:hover:bg-white/10'
                      }`}
                    >
                      {style.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Controls Grid */}
              <div className="grid grid-cols-2 gap-4">
                {/* Aspect Ratio */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-gray-400 mb-2">Aspect Ratio</label>
                  <select
                    value={settings.aspectRatio}
                    onChange={(e) => setSettings({ ...settings, aspectRatio: e.target.value as any })}
                    className="w-full bg-white dark:bg-black/40 border border-slate-200 dark:border-white/10 rounded-lg p-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors"
                  >
                    {ASPECT_RATIOS.map(r => (
                      <option key={r.value} value={r.value}>{r.label} ({r.value})</option>
                    ))}
                  </select>
                </div>

                {/* Quality */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-gray-400 mb-2">Quality</label>
                  <div className="flex bg-slate-100 dark:bg-black/40 rounded-lg p-1 border border-slate-200 dark:border-white/10 transition-colors">
                    <button
                      onClick={() => setSettings({ ...settings, quality: 'standard' })}
                      className={`flex-1 text-xs py-1.5 rounded-md transition-all ${settings.quality === 'standard' ? 'bg-white dark:bg-white/10 text-slate-900 dark:text-white shadow-sm' : 'text-slate-500 dark:text-gray-500'}`}
                    >
                      Fast
                    </button>
                    <button
                      onClick={() => setSettings({ ...settings, quality: 'hd' })}
                      className={`flex-1 text-xs py-1.5 rounded-md transition-all ${settings.quality === 'hd' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-500 dark:text-gray-500'}`}
                    >
                      HD
                    </button>
                  </div>
                </div>
              </div>

              {/* Generate Button */}
              <button
                onClick={handleGenerate}
                disabled={isGenerating || !prompt}
                className="w-full mt-4 py-4 rounded-xl bg-gradient-to-r from-indigo-600 to-pink-600 text-white font-bold text-lg hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg shadow-indigo-500/30 flex items-center justify-center gap-2"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Dreaming...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5" />
                    Generate Art
                  </>
                )}
              </button>

              {error && (
                <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-600 dark:text-red-200 text-sm">
                  {error}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Preview Panel */}
        <div className="w-full lg:w-2/3">
          <div className="glass-panel p-1 rounded-2xl h-full min-h-[500px] flex flex-col relative overflow-hidden group shadow-lg dark:shadow-none">
            {currentImage ? (
              <div className="relative w-full h-full flex-1 rounded-xl overflow-hidden bg-slate-100 dark:bg-black/50 flex items-center justify-center transition-colors">
                <img 
                  src={currentImage.url} 
                  alt={currentImage.prompt} 
                  className="max-h-[600px] w-auto h-auto object-contain shadow-2xl"
                />
                
                {/* Overlay Actions */}
                <div className="absolute top-4 right-4 flex gap-2">
                  <span className="px-3 py-1 rounded-full bg-black/60 backdrop-blur text-white text-xs font-mono border border-white/10">
                    {currentImage.model === 'Pro' ? 'HD' : 'FAST'}
                  </span>
                  <span className="px-3 py-1 rounded-full bg-black/60 backdrop-blur text-white text-xs font-mono border border-white/10">
                    {currentImage.aspectRatio}
                  </span>
                </div>

                <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/90 via-black/50 to-transparent translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                  <p className="text-white text-sm line-clamp-2 mb-4 opacity-90">{currentImage.prompt}</p>
                  <div className="flex gap-3">
                    <button 
                      onClick={() => handleDownload(currentImage)}
                      className="flex-1 py-2 bg-white text-black font-semibold rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center gap-2"
                    >
                      <Download className="w-4 h-4" /> Download
                    </button>
                    <button 
                      onClick={handleGenerate}
                      className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors border border-white/10"
                      title="Regenerate"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center text-slate-400 dark:text-gray-500 space-y-4">
                 <div className="w-20 h-20 rounded-full bg-slate-100 dark:bg-white/5 flex items-center justify-center mb-4 transition-colors">
                    <ImageIcon className="w-8 h-8 opacity-50" />
                 </div>
                 <p className="text-lg font-medium text-slate-600 dark:text-gray-400">Your imagination awaits</p>
                 <p className="text-sm max-w-xs text-center">Enter a prompt and select a style to generate your first masterpiece.</p>
              </div>
            )}
            
            {isGenerating && (
              <div className="absolute inset-0 bg-white/80 dark:bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center z-20 transition-colors">
                 <div className="relative">
                   <div className="w-16 h-16 border-4 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin"></div>
                   <div className="absolute inset-0 flex items-center justify-center">
                     <Sparkles className="w-6 h-6 text-indigo-500 animate-pulse" />
                   </div>
                 </div>
                 <p className="mt-4 text-indigo-600 dark:text-indigo-300 font-medium animate-pulse">Creating masterpiece...</p>
                 <p className="text-xs text-slate-500 dark:text-gray-500 mt-2">Powered by Gemini</p>
              </div>
            )}
          </div>

          {/* History Strip */}
          {generatedImages.length > 1 && (
            <div className="mt-6">
              <h3 className="text-sm font-medium text-slate-500 dark:text-gray-400 mb-3 flex items-center gap-2">
                <Layers className="w-4 h-4" /> Recent Creations
              </h3>
              <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide py-2">
                {generatedImages.slice(1).map((img) => (
                  <div 
                    key={img.id} 
                    className="flex-shrink-0 w-24 h-24 rounded-lg overflow-hidden border border-slate-200 dark:border-white/10 cursor-pointer hover:ring-2 hover:ring-indigo-500 transition-all duration-300 relative group/item bg-slate-100 dark:bg-white/5 hover:scale-105 hover:shadow-lg"
                  >
                    <img 
                      src={img.url} 
                      alt="" 
                      className="w-full h-full object-cover" 
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/item:opacity-100 transition-all duration-300 flex items-center justify-center backdrop-blur-[1px]">
                      <button 
                        onClick={() => handleDownload(img)} 
                        className="text-white p-2 rounded-full bg-white/20 hover:bg-white/40 transform scale-90 group-hover/item:scale-100 transition-all"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Generator;