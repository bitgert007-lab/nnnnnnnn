import React, { useState, useMemo } from "react";
import {
  View,
  StyleSheet,
  ScrollView,
  Pressable,
  TextInput,
  Modal,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { ThemedText } from "@/components/ThemedText";
import { CircularProgress } from "@/components/CircularProgress";
import { ProgressBar } from "@/components/ProgressBar";
import { CategoryIcon } from "@/components/CategoryIcon";
import { useTheme } from "@/hooks/useTheme";
import { useExpenses } from "@/context/ExpenseContext";
import { Spacing, BorderRadius, CategoryColors } from "@/constants/theme";

export default function BudgetScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();
  const {
    expenses,
    categories,
    budget,
    isLoading,
    setBudget,
    getCurrencySymbol,
    getMonthlyTotal,
    getCategoryTotal,
  } = useExpenses();

  const [showBudgetModal, setShowBudgetModal] = useState(false);
  const [newBudgetLimit, setNewBudgetLimit] = useState("");

  const currencySymbol = getCurrencySymbol();
  const monthlyExpense = getMonthlyTotal("expense");
  const budgetLimit = budget?.monthlyLimit || 2000;
  const remaining = Math.max(budgetLimit - monthlyExpense, 0);
  const budgetProgress = budgetLimit > 0 ? monthlyExpense / budgetLimit : 0;

  const currentMonth = new Date().toLocaleDateString("en-US", {
    month: "long",
    year: "numeric",
  });

  const categoryBudgets = useMemo(() => {
    return categories.map((category) => {
      const spent = getCategoryTotal(category.id);
      const limit = budget?.categoryLimits?.[category.id] || 0;
      const progress = limit > 0 ? spent / limit : 0;

      return {
        ...category,
        spent,
        limit,
        progress,
      };
    }).filter((c) => c.spent > 0 || c.limit > 0);
  }, [categories, budget, getCategoryTotal]);

  const warningCategory = useMemo(() => {
    return categoryBudgets.find((c) => c.limit > 0 && c.progress >= 0.9);
  }, [categoryBudgets]);

  const handleSaveBudget = async () => {
    const limit = parseFloat(newBudgetLimit);
    if (isNaN(limit) || limit <= 0) return;

    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    await setBudget({
      monthlyLimit: limit,
      categoryLimits: budget?.categoryLimits || {},
      month: new Date().toLocaleDateString("en-US", { month: "long" }),
      year: new Date().getFullYear(),
    });
    setShowBudgetModal(false);
    setNewBudgetLimit("");
  };

  if (isLoading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: theme.backgroundRoot }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={{
          paddingTop: headerHeight + Spacing.xl,
          paddingBottom: tabBarHeight + Spacing["2xl"],
          paddingHorizontal: Spacing.lg,
        }}
        scrollIndicatorInsets={{ bottom: insets.bottom }}
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.progressCard, { backgroundColor: theme.backgroundDefault }]}>
          <View style={styles.progressContainer}>
            <CircularProgress
              progress={1 - budgetProgress}
              size={200}
              strokeWidth={16}
              color={budgetProgress > 0.9 ? theme.error : theme.primary}
              label="REMAINING"
              value={`${currencySymbol}${remaining.toFixed(0)}`}
            />
          </View>
          <View style={styles.budgetInfo}>
            <ThemedText style={[styles.budgetLabel, { color: theme.textSecondary }]}>
              Total Budget
            </ThemedText>
            <ThemedText style={styles.budgetAmount}>
              {currencySymbol}{monthlyExpense.toFixed(0)}
              <ThemedText style={[styles.budgetLimit, { color: theme.textSecondary }]}>
                {" "}/ {currencySymbol}{budgetLimit.toFixed(0)}
              </ThemedText>
            </ThemedText>
          </View>
        </View>

        {warningCategory ? (
          <View style={[styles.alertCard, { backgroundColor: theme.error + "20" }]}>
            <View style={styles.alertContent}>
              <Feather name="alert-triangle" size={20} color={theme.error} />
              <View style={styles.alertTextContainer}>
                <ThemedText style={[styles.alertTitle, { color: theme.error }]}>
                  ALERT
                </ThemedText>
                <ThemedText style={styles.alertMessage}>
                  {warningCategory.name} Limit
                </ThemedText>
                <ThemedText style={[styles.alertDescription, { color: theme.textSecondary }]}>
                  You've used {Math.round(warningCategory.progress * 100)}% of your{" "}
                  {warningCategory.name} budget.
                </ThemedText>
              </View>
            </View>
            <Pressable style={styles.alertButton}>
              <ThemedText style={styles.alertButtonText}>View Details</ThemedText>
              <Feather name="arrow-right" size={16} color={theme.text} />
            </Pressable>
          </View>
        ) : null}

        <View style={styles.sectionHeader}>
          <ThemedText style={styles.sectionTitle}>Category Breakdown</ThemedText>
          <Pressable>
            <ThemedText style={{ color: theme.primary }}>View All</ThemedText>
          </Pressable>
        </View>

        {categoryBudgets.length > 0 ? (
          <View style={styles.categoriesList}>
            {categoryBudgets.map((category) => (
              <View
                key={category.id}
                style={[styles.categoryCard, { backgroundColor: theme.backgroundDefault }]}
              >
                <CategoryIcon icon={category.icon} color={category.color} />
                <View style={styles.categoryContent}>
                  <View style={styles.categoryHeader}>
                    <ThemedText style={styles.categoryName}>{category.name}</ThemedText>
                    <ThemedText
                      style={[
                        styles.categoryPercentage,
                        { color: category.progress > 0.9 ? theme.error : theme.text },
                      ]}
                    >
                      {category.limit > 0 ? `${Math.round(category.progress * 100)}%` : "-"}
                    </ThemedText>
                  </View>
                  <ProgressBar
                    progress={category.progress}
                    color={category.progress > 0.9 ? theme.error : category.color}
                    height={8}
                  />
                  <ThemedText style={[styles.categorySpent, { color: theme.textSecondary }]}>
                    {currencySymbol}{category.spent.toFixed(0)}
                    {category.limit > 0 ? ` of ${currencySymbol}${category.limit.toFixed(0)}` : ""}
                  </ThemedText>
                </View>
              </View>
            ))}
          </View>
        ) : (
          <View style={[styles.emptyCategories, { backgroundColor: theme.backgroundDefault }]}>
            <Feather name="sliders" size={48} color={theme.textSecondary} />
            <ThemedText style={[styles.emptyText, { color: theme.textSecondary }]}>
              No budget data yet
            </ThemedText>
          </View>
        )}

        <Pressable
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            setNewBudgetLimit(budgetLimit.toString());
            setShowBudgetModal(true);
          }}
          style={({ pressed }) => [
            styles.setBudgetButton,
            { backgroundColor: theme.primary, opacity: pressed ? 0.8 : 1 },
          ]}
        >
          <Feather name="edit-3" size={20} color={theme.buttonText} />
          <ThemedText style={[styles.setBudgetText, { color: theme.buttonText }]}>
            SET BUDGET
          </ThemedText>
        </Pressable>
      </ScrollView>

      <Modal
        visible={showBudgetModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowBudgetModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: theme.backgroundDefault }]}>
            <ThemedText style={styles.modalTitle}>Set Monthly Budget</ThemedText>
            <View
              style={[styles.modalInput, { backgroundColor: theme.inputBackground }]}
            >
              <ThemedText style={[styles.currencySymbol, { color: theme.textSecondary }]}>
                {currencySymbol}
              </ThemedText>
              <TextInput
                style={[styles.budgetInput, { color: theme.text }]}
                value={newBudgetLimit}
                onChangeText={setNewBudgetLimit}
                keyboardType="numeric"
                placeholder="0.00"
                placeholderTextColor={theme.textSecondary}
                autoFocus
              />
            </View>
            <View style={styles.modalButtons}>
              <Pressable
                onPress={() => setShowBudgetModal(false)}
                style={[styles.modalButton, { backgroundColor: theme.backgroundSecondary }]}
              >
                <ThemedText>Cancel</ThemedText>
              </Pressable>
              <Pressable
                onPress={handleSaveBudget}
                style={[styles.modalButton, { backgroundColor: theme.primary }]}
              >
                <ThemedText style={{ color: theme.buttonText }}>Save</ThemedText>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  scrollView: {
    flex: 1,
  },
  progressCard: {
    padding: Spacing.xl,
    borderRadius: BorderRadius.md,
    alignItems: "center",
    marginBottom: Spacing.xl,
  },
  progressContainer: {
    marginBottom: Spacing.lg,
  },
  budgetInfo: {
    alignItems: "center",
  },
  budgetLabel: {
    fontSize: 14,
    marginBottom: Spacing.xs,
  },
  budgetAmount: {
    fontSize: 24,
    fontWeight: "600",
  },
  budgetLimit: {
    fontSize: 16,
    fontWeight: "400",
  },
  alertCard: {
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.xl,
  },
  alertContent: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: Spacing.md,
  },
  alertTextContainer: {
    flex: 1,
  },
  alertTitle: {
    fontSize: 12,
    fontWeight: "700",
    letterSpacing: 0.5,
    marginBottom: 2,
  },
  alertMessage: {
    fontSize: 18,
    fontWeight: "600",
    marginBottom: 4,
  },
  alertDescription: {
    fontSize: 14,
  },
  alertButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
    marginTop: Spacing.md,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    alignSelf: "flex-start",
    backgroundColor: "rgba(0, 0, 0, 0.1)",
    borderRadius: BorderRadius.xs,
  },
  alertButtonText: {
    fontSize: 14,
    fontWeight: "500",
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "600",
  },
  categoriesList: {
    gap: Spacing.md,
    marginBottom: Spacing.xl,
  },
  categoryCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
  },
  categoryContent: {
    flex: 1,
    marginLeft: Spacing.md,
  },
  categoryHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.sm,
  },
  categoryName: {
    fontSize: 16,
    fontWeight: "500",
  },
  categoryPercentage: {
    fontSize: 16,
    fontWeight: "600",
  },
  categorySpent: {
    fontSize: 12,
    marginTop: Spacing.xs,
  },
  emptyCategories: {
    padding: Spacing["3xl"],
    borderRadius: BorderRadius.md,
    alignItems: "center",
    marginBottom: Spacing.xl,
  },
  emptyText: {
    fontSize: 16,
    marginTop: Spacing.md,
  },
  setBudgetButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    height: Spacing.buttonHeight,
    borderRadius: BorderRadius.full,
    gap: Spacing.sm,
  },
  setBudgetText: {
    fontSize: 16,
    fontWeight: "600",
    letterSpacing: 0.5,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
    padding: Spacing.lg,
  },
  modalContent: {
    width: "100%",
    padding: Spacing.xl,
    borderRadius: BorderRadius.md,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "600",
    textAlign: "center",
    marginBottom: Spacing.xl,
  },
  modalInput: {
    flexDirection: "row",
    alignItems: "center",
    height: Spacing.inputHeight,
    borderRadius: BorderRadius.sm,
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  currencySymbol: {
    fontSize: 20,
    fontWeight: "500",
    marginRight: Spacing.sm,
  },
  budgetInput: {
    flex: 1,
    fontSize: 24,
    fontWeight: "600",
  },
  modalButtons: {
    flexDirection: "row",
    gap: Spacing.md,
  },
  modalButton: {
    flex: 1,
    height: Spacing.buttonHeight,
    borderRadius: BorderRadius.sm,
    alignItems: "center",
    justifyContent: "center",
  },
});
