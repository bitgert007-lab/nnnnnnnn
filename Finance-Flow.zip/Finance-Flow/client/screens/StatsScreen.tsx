import React, { useMemo, useState } from "react";
import {
  View,
  StyleSheet,
  ScrollView,
  Pressable,
  ActivityIndicator,
  Share,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { ThemedText } from "@/components/ThemedText";
import { ProgressBar } from "@/components/ProgressBar";
import { CategoryIcon } from "@/components/CategoryIcon";
import { useTheme } from "@/hooks/useTheme";
import { useExpenses } from "@/context/ExpenseContext";
import { Spacing, BorderRadius, CategoryColors } from "@/constants/theme";

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export default function StatsScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();
  const { expenses, categories, isLoading, getCurrencySymbol } = useExpenses();

  const currencySymbol = getCurrencySymbol();
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());

  const monthlyData = useMemo(() => {
    const currentYear = new Date().getFullYear();
    const data: number[] = [];

    for (let i = 0; i < 6; i++) {
      const month = (selectedMonth - 5 + i + 12) % 12;
      const year = selectedMonth - 5 + i < 0 ? currentYear - 1 : currentYear;
      const total = expenses
        .filter((e) => {
          const date = new Date(e.date);
          return date.getMonth() === month && date.getFullYear() === year && e.type === "expense";
        })
        .reduce((sum, e) => sum + e.amount, 0);
      data.push(total);
    }

    return data;
  }, [expenses, selectedMonth]);

  const currentMonthTotal = useMemo(() => {
    const now = new Date();
    return expenses
      .filter((e) => {
        const date = new Date(e.date);
        return (
          date.getMonth() === now.getMonth() &&
          date.getFullYear() === now.getFullYear() &&
          e.type === "expense"
        );
      })
      .reduce((sum, e) => sum + e.amount, 0);
  }, [expenses]);

  const lastMonthTotal = useMemo(() => {
    const now = new Date();
    const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    return expenses
      .filter((e) => {
        const date = new Date(e.date);
        return (
          date.getMonth() === lastMonth.getMonth() &&
          date.getFullYear() === lastMonth.getFullYear() &&
          e.type === "expense"
        );
      })
      .reduce((sum, e) => sum + e.amount, 0);
  }, [expenses]);

  const percentChange = useMemo(() => {
    if (lastMonthTotal === 0) return 0;
    return Math.round(((currentMonthTotal - lastMonthTotal) / lastMonthTotal) * 100);
  }, [currentMonthTotal, lastMonthTotal]);

  const topCategories = useMemo(() => {
    const now = new Date();
    const breakdown: { [key: string]: number } = {};

    expenses.forEach((expense) => {
      if (expense.type !== "expense") return;
      const date = new Date(expense.date);
      if (date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear()) {
        breakdown[expense.categoryId] = (breakdown[expense.categoryId] || 0) + expense.amount;
      }
    });

    return Object.entries(breakdown)
      .map(([categoryId, total]) => {
        const category = categories.find((c) => c.id === categoryId);
        return {
          categoryId,
          total,
          name: category?.name || "Other",
          icon: category?.icon || "circle",
          color: category?.color || CategoryColors.others,
          percentage: currentMonthTotal > 0 ? Math.round((total / currentMonthTotal) * 100) : 0,
        };
      })
      .sort((a, b) => b.total - a.total);
  }, [expenses, categories, currentMonthTotal]);

  const maxMonthlyValue = Math.max(...monthlyData, 1);

  const handleExportCSV = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const headers = "Date,Description,Category,Amount,Type\n";
    const rows = expenses
      .map((e) => {
        const category = categories.find((c) => c.id === e.categoryId)?.name || "Other";
        return `${e.date},${e.description},${category},${e.amount},${e.type}`;
      })
      .join("\n");
    const csvContent = headers + rows;

    try {
      await Share.share({
        message: csvContent,
        title: "Expense Report",
      });
    } catch (error) {
      console.error("Export failed:", error);
    }
  };

  const handleExportPDF = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const reportText = `
Expense Report - ${MONTHS[new Date().getMonth()]} ${new Date().getFullYear()}

Total Spent: ${currencySymbol}${currentMonthTotal.toFixed(2)}
Change from last month: ${percentChange >= 0 ? "+" : ""}${percentChange}%

Top Categories:
${topCategories.map((c) => `- ${c.name}: ${currencySymbol}${c.total.toFixed(2)} (${c.percentage}%)`).join("\n")}
    `;

    try {
      await Share.share({
        message: reportText,
        title: "Expense Report PDF",
      });
    } catch (error) {
      console.error("Export failed:", error);
    }
  };

  if (isLoading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: theme.backgroundRoot }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={{
          paddingTop: headerHeight + Spacing.xl,
          paddingBottom: tabBarHeight + Spacing["2xl"],
          paddingHorizontal: Spacing.lg,
        }}
        scrollIndicatorInsets={{ bottom: insets.bottom }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.summarySection}>
          <ThemedText style={[styles.summaryLabel, { color: theme.textSecondary }]}>
            Total Spent this Month
          </ThemedText>
          <ThemedText style={styles.summaryAmount}>
            {currencySymbol}{currentMonthTotal.toFixed(2)}
          </ThemedText>
          <View style={styles.changeContainer}>
            <Feather
              name={percentChange >= 0 ? "trending-up" : "trending-down"}
              size={16}
              color={percentChange >= 0 ? theme.error : theme.success}
            />
            <ThemedText
              style={[
                styles.changeText,
                { color: percentChange >= 0 ? theme.error : theme.success },
              ]}
            >
              {percentChange >= 0 ? "+" : ""}{percentChange}%
            </ThemedText>
            <ThemedText style={[styles.changeLabel, { color: theme.textSecondary }]}>
              vs. last month
            </ThemedText>
          </View>
        </View>

        <View style={[styles.chartCard, { backgroundColor: theme.backgroundDefault }]}>
          <View style={styles.chartHeader}>
            <ThemedText style={styles.chartTitle}>Monthly Activity</ThemedText>
            <View style={styles.chartLegend}>
              <View style={[styles.legendDot, { backgroundColor: theme.primary }]} />
              <ThemedText style={[styles.legendText, { color: theme.textSecondary }]}>
                Spending
              </ThemedText>
            </View>
          </View>

          <View style={styles.barChart}>
            {monthlyData.map((value, index) => {
              const monthIndex = (selectedMonth - 5 + index + 12) % 12;
              const height = (value / maxMonthlyValue) * 120;
              const isCurrentMonth = index === 5;

              return (
                <View key={index} style={styles.barContainer}>
                  <View style={styles.barWrapper}>
                    <View
                      style={[
                        styles.bar,
                        {
                          height: Math.max(height, 4),
                          backgroundColor: isCurrentMonth
                            ? theme.primary
                            : theme.primary + "60",
                        },
                      ]}
                    />
                    {isCurrentMonth ? (
                      <View
                        style={[
                          styles.barHighlight,
                          {
                            height: Math.max(height * 0.4, 2),
                            backgroundColor: theme.primary + "40",
                          },
                        ]}
                      />
                    ) : null}
                  </View>
                  <ThemedText
                    style={[
                      styles.barLabel,
                      { color: isCurrentMonth ? theme.text : theme.textSecondary },
                    ]}
                  >
                    {MONTHS[monthIndex]}
                  </ThemedText>
                </View>
              );
            })}
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <ThemedText style={styles.sectionTitle}>Top Categories</ThemedText>
          <Pressable>
            <ThemedText style={{ color: theme.primary }}>See All</ThemedText>
          </Pressable>
        </View>

        {topCategories.length > 0 ? (
          <View style={styles.categoriesList}>
            {topCategories.slice(0, 4).map((category, index) => (
              <View
                key={category.categoryId}
                style={[styles.categoryCard, { backgroundColor: theme.backgroundDefault }]}
              >
                <CategoryIcon icon={category.icon} color={category.color} />
                <View style={styles.categoryContent}>
                  <View style={styles.categoryHeader}>
                    <ThemedText style={styles.categoryName}>{category.name}</ThemedText>
                    <ThemedText style={styles.categoryAmount}>
                      {currencySymbol}{category.total.toFixed(0)}
                    </ThemedText>
                  </View>
                  <View style={styles.categoryProgress}>
                    <ProgressBar
                      progress={category.percentage / 100}
                      color={category.color}
                      height={6}
                    />
                    <ThemedText style={[styles.categoryPercentage, { color: theme.textSecondary }]}>
                      {category.percentage}%
                    </ThemedText>
                  </View>
                </View>
              </View>
            ))}
          </View>
        ) : (
          <View style={[styles.emptyCategories, { backgroundColor: theme.backgroundDefault }]}>
            <Feather name="bar-chart-2" size={48} color={theme.textSecondary} />
            <ThemedText style={[styles.emptyText, { color: theme.textSecondary }]}>
              No spending data yet
            </ThemedText>
          </View>
        )}

        <View style={styles.exportButtons}>
          <Pressable
            onPress={handleExportPDF}
            style={({ pressed }) => [
              styles.exportButton,
              { backgroundColor: theme.primary, opacity: pressed ? 0.8 : 1 },
            ]}
          >
            <Feather name="file-text" size={20} color={theme.buttonText} />
            <ThemedText style={[styles.exportText, { color: theme.buttonText }]}>
              Export PDF
            </ThemedText>
          </Pressable>
          <Pressable
            onPress={handleExportCSV}
            style={({ pressed }) => [
              styles.exportButton,
              { backgroundColor: theme.backgroundDefault, opacity: pressed ? 0.8 : 1 },
            ]}
          >
            <Feather name="download" size={20} color={theme.text} />
            <ThemedText style={styles.exportText}>Export CSV</ThemedText>
          </Pressable>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  scrollView: {
    flex: 1,
  },
  summarySection: {
    alignItems: "center",
    marginBottom: Spacing["2xl"],
  },
  summaryLabel: {
    fontSize: 14,
    marginBottom: Spacing.xs,
  },
  summaryAmount: {
    fontSize: 40,
    fontWeight: "700",
    marginBottom: Spacing.sm,
  },
  changeContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
  },
  changeText: {
    fontSize: 14,
    fontWeight: "600",
  },
  changeLabel: {
    fontSize: 14,
  },
  chartCard: {
    padding: Spacing.xl,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.xl,
  },
  chartHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.xl,
  },
  chartTitle: {
    fontSize: 16,
    fontWeight: "600",
  },
  chartLegend: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
  },
  legendDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  legendText: {
    fontSize: 12,
  },
  barChart: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-end",
    height: 150,
  },
  barContainer: {
    alignItems: "center",
    flex: 1,
  },
  barWrapper: {
    width: 32,
    height: 120,
    justifyContent: "flex-end",
    alignItems: "center",
  },
  bar: {
    width: 24,
    borderRadius: 4,
  },
  barHighlight: {
    width: 24,
    borderRadius: 4,
    marginTop: 2,
  },
  barLabel: {
    fontSize: 12,
    marginTop: Spacing.sm,
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "600",
  },
  categoriesList: {
    gap: Spacing.md,
    marginBottom: Spacing.xl,
  },
  categoryCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
  },
  categoryContent: {
    flex: 1,
    marginLeft: Spacing.md,
  },
  categoryHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.sm,
  },
  categoryName: {
    fontSize: 16,
    fontWeight: "500",
  },
  categoryAmount: {
    fontSize: 16,
    fontWeight: "600",
  },
  categoryProgress: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  categoryPercentage: {
    fontSize: 14,
    minWidth: 40,
    textAlign: "right",
  },
  emptyCategories: {
    padding: Spacing["3xl"],
    borderRadius: BorderRadius.md,
    alignItems: "center",
    marginBottom: Spacing.xl,
  },
  emptyText: {
    fontSize: 16,
    marginTop: Spacing.md,
  },
  exportButtons: {
    flexDirection: "row",
    gap: Spacing.md,
  },
  exportButton: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    height: Spacing.buttonHeight,
    borderRadius: BorderRadius.sm,
    gap: Spacing.sm,
  },
  exportText: {
    fontSize: 16,
    fontWeight: "600",
  },
});
