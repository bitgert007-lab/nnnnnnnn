export interface User {
  id: string;
  email: string;
  name: string;
  currency: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  color: string;
  isCustom: boolean;
}

export interface Expense {
  id: string;
  amount: number;
  categoryId: string;
  description: string;
  date: string;
  type: "expense" | "income";
  isRecurring: boolean;
  recurringFrequency?: "daily" | "weekly" | "monthly" | "yearly";
  currency: string;
}

export interface Budget {
  id: string;
  monthlyLimit: number;
  categoryLimits: { [categoryId: string]: number };
  month: string;
  year: number;
}

export interface UserPreferences {
  currency: string;
  darkMode: boolean;
  notifications: boolean;
}

export type FilterPeriod = "daily" | "weekly" | "monthly" | "yearly";
