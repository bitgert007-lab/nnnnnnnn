import React, { useState, useEffect } from 'react';
import { ArrowRight, Star, CheckCircle2, Instagram, Twitter, Github } from 'lucide-react';
import Header from './components/Header';
import Generator from './components/Generator';
import Features from './components/Features';

function App() {
  const [isDark, setIsDark] = useState(true);

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  const toggleTheme = () => setIsDark(!isDark);

  return (
    <div className="min-h-screen font-sans selection:bg-indigo-500/30 text-slate-900 dark:text-white">
      
      {/* Global Background */}
      <div className="fixed inset-0 bg-slate-50 dark:bg-[#0f172a] -z-20 transition-colors duration-300"></div>
      <div className="fixed inset-0 bg-gradient-to-br from-indigo-100/40 via-white/10 to-pink-100/40 dark:from-indigo-900/20 dark:via-[#0f172a] dark:to-pink-900/20 -z-10 transition-colors duration-300"></div>
      
      {/* Animated Blobs */}
      <div className="fixed top-0 left-1/4 w-[500px] h-[500px] bg-purple-400/20 dark:bg-purple-600/20 rounded-full blur-[120px] mix-blend-multiply dark:mix-blend-screen animate-blob -z-10"></div>
      <div className="fixed bottom-0 right-1/4 w-[500px] h-[500px] bg-blue-400/20 dark:bg-blue-600/10 rounded-full blur-[120px] mix-blend-multiply dark:mix-blend-screen animate-blob animation-delay-2000 -z-10"></div>

      <Header isDark={isDark} toggleTheme={toggleTheme} />

      {/* Hero Section */}
      <section id="hero" className="pt-40 pb-20 px-6 relative">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-200/50 dark:bg-white/5 border border-slate-300 dark:border-white/10 mb-8 backdrop-blur-sm animate-fade-in-up transition-colors">
            <span className="flex h-2 w-2 rounded-full bg-green-500 dark:bg-green-400 animate-pulse"></span>
            <span className="text-sm font-medium text-slate-700 dark:text-gray-300">Powered by Gemini 2.5 Flash</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-display font-bold leading-[1.1] mb-8 tracking-tight text-slate-900 dark:text-white">
            Turn words into <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 animate-gradient">
              Visual Masterpieces
            </span>
          </h1>
          
          <p className="text-xl text-slate-600 dark:text-gray-400 mb-10 max-w-2xl mx-auto leading-relaxed">
            Generate production-quality assets, illustrations, and concept art in seconds with the power of Google's latest AI models.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button onClick={() => document.getElementById('generator')?.scrollIntoView({behavior: 'smooth'})} className="px-8 py-4 rounded-full bg-slate-900 dark:bg-white text-white dark:text-black font-bold text-lg hover:opacity-90 transition-all flex items-center gap-2 shadow-xl shadow-indigo-500/20 dark:shadow-[0_0_40px_-10px_rgba(255,255,255,0.3)]">
              Start Generating Free <ArrowRight className="w-5 h-5" />
            </button>
            <button onClick={() => document.getElementById('features')?.scrollIntoView({behavior: 'smooth'})} className="px-8 py-4 rounded-full bg-white/50 dark:bg-white/5 text-slate-900 dark:text-white font-medium text-lg border border-slate-200 dark:border-white/10 hover:bg-white/80 dark:hover:bg-white/10 transition-all">
              View Examples
            </button>
          </div>

          <div className="mt-12 flex items-center justify-center gap-8 text-slate-500 dark:text-gray-500 text-sm font-medium">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-indigo-500" />
              <span>No credit card required</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-indigo-500" />
              <span>Unlimited standard generations</span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Generator App Section */}
      <div className="relative">
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-slate-300 dark:via-white/20 to-transparent"></div>
        <Generator />
      </div>

      <Features />

      {/* Social Proof */}
      <section id="showcase" className="py-20 border-y border-slate-200 dark:border-white/5 bg-slate-100/50 dark:bg-black/20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="text-3xl font-display font-bold mb-2 text-slate-900 dark:text-white">Community Showcase</h2>
              <p className="text-slate-600 dark:text-gray-400">Created by users like you</p>
            </div>
            <div className="flex gap-1">
               {[1,2,3,4,5].map(i => <Star key={i} className="w-4 h-4 text-yellow-500 fill-yellow-500" />)}
               <span className="text-sm ml-2 text-slate-600 dark:text-gray-300">4.9/5 from 10k+ users</span>
            </div>
          </div>
          
          <div className="columns-2 md:columns-4 gap-4 space-y-4">
            <div className="relative group rounded-xl overflow-hidden cursor-pointer shadow-md dark:shadow-none">
               <img src="https://picsum.photos/400/600" alt="Art" className="w-full rounded-xl hover:scale-105 transition-transform duration-500" />
            </div>
            <div className="relative group rounded-xl overflow-hidden cursor-pointer shadow-md dark:shadow-none">
               <img src="https://picsum.photos/400/400" alt="Art" className="w-full rounded-xl hover:scale-105 transition-transform duration-500" />
            </div>
            <div className="relative group rounded-xl overflow-hidden cursor-pointer shadow-md dark:shadow-none">
               <img src="https://picsum.photos/400/500" alt="Art" className="w-full rounded-xl hover:scale-105 transition-transform duration-500" />
            </div>
            <div className="relative group rounded-xl overflow-hidden cursor-pointer shadow-md dark:shadow-none">
               <img src="https://picsum.photos/400/300" alt="Art" className="w-full rounded-xl hover:scale-105 transition-transform duration-500" />
            </div>
             <div className="relative group rounded-xl overflow-hidden cursor-pointer shadow-md dark:shadow-none">
               <img src="https://picsum.photos/400/550" alt="Art" className="w-full rounded-xl hover:scale-105 transition-transform duration-500" />
            </div>
             <div className="relative group rounded-xl overflow-hidden cursor-pointer shadow-md dark:shadow-none">
               <img src="https://picsum.photos/400/450" alt="Art" className="w-full rounded-xl hover:scale-105 transition-transform duration-500" />
            </div>
          </div>
        </div>
      </section>

      {/* Pricing / CTA */}
      <section id="pricing" className="py-24 px-6">
        <div className="max-w-5xl mx-auto glass-panel rounded-3xl p-12 text-center relative overflow-hidden shadow-xl dark:shadow-none">
          <div className="absolute top-0 right-0 w-64 h-64 bg-pink-500/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
          
          <h2 className="text-3xl md:text-5xl font-display font-bold mb-6 text-slate-900 dark:text-white">Start Creating Today</h2>
          <p className="text-xl text-slate-600 dark:text-gray-400 mb-8 max-w-2xl mx-auto">
            Unleash your creativity with the power of Gemini. No credit card required to start generating standard quality images.
          </p>
          <button onClick={() => document.getElementById('generator')?.scrollIntoView({behavior: 'smooth'})} className="px-10 py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full font-bold text-lg transition-all shadow-xl shadow-indigo-600/20">
            Launch Studio
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0a0f1c] pt-20 pb-10 px-6 transition-colors">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-12 mb-16">
            <div className="col-span-2">
               <span className="text-2xl font-display font-bold text-slate-900 dark:text-white tracking-tight mb-6 block">
                Lumina
              </span>
              <p className="text-slate-600 dark:text-gray-400 max-w-sm">
                Next-generation AI image generation platform powered by Google's Gemini models. Built for designers, developers, and dreamers.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-6 text-slate-900 dark:text-gray-200">Product</h4>
              <ul className="space-y-4 text-slate-600 dark:text-gray-400 text-sm">
                <li className="hover:text-indigo-600 dark:hover:text-white cursor-pointer">Features</li>
                <li className="hover:text-indigo-600 dark:hover:text-white cursor-pointer">Showcase</li>
                <li className="hover:text-indigo-600 dark:hover:text-white cursor-pointer">API</li>
                <li className="hover:text-indigo-600 dark:hover:text-white cursor-pointer">Pricing</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-6 text-slate-900 dark:text-gray-200">Legal</h4>
              <ul className="space-y-4 text-slate-600 dark:text-gray-400 text-sm">
                <li className="hover:text-indigo-600 dark:hover:text-white cursor-pointer">Privacy Policy</li>
                <li className="hover:text-indigo-600 dark:hover:text-white cursor-pointer">Terms of Service</li>
                <li className="hover:text-indigo-600 dark:hover:text-white cursor-pointer">Cookie Policy</li>
              </ul>
            </div>
          </div>
          <div className="flex flex-col md:flex-row justify-between items-center pt-8 border-t border-slate-200 dark:border-white/5 text-slate-500 dark:text-gray-500 text-sm">
            <p>© 2024 Lumina AI Studio. All rights reserved.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <Twitter className="w-5 h-5 hover:text-indigo-600 dark:hover:text-white cursor-pointer transition-colors" />
              <Instagram className="w-5 h-5 hover:text-indigo-600 dark:hover:text-white cursor-pointer transition-colors" />
              <Github className="w-5 h-5 hover:text-indigo-600 dark:hover:text-white cursor-pointer transition-colors" />
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;