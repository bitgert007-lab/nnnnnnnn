import React from "react";
import { View, StyleSheet } from "react-native";
import Svg, { Circle, G } from "react-native-svg";
import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";

interface DonutChartProps {
  data: { value: number; color: string; label: string }[];
  size?: number;
  strokeWidth?: number;
  centerLabel?: string;
  centerValue?: string;
}

export function DonutChart({
  data,
  size = 180,
  strokeWidth = 20,
  centerLabel,
  centerValue,
}: DonutChartProps) {
  const { theme } = useTheme();
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const center = size / 2;

  const total = data.reduce((sum, item) => sum + item.value, 0);
  let currentAngle = -90;

  const segments = data.map((item) => {
    const percentage = total > 0 ? item.value / total : 0;
    const strokeDasharray = `${circumference * percentage} ${circumference * (1 - percentage)}`;
    const rotation = currentAngle;
    currentAngle += percentage * 360;

    return {
      ...item,
      percentage,
      strokeDasharray,
      rotation,
    };
  });

  return (
    <View style={styles.container}>
      <Svg width={size} height={size}>
        <Circle
          cx={center}
          cy={center}
          r={radius}
          stroke={theme.backgroundSecondary}
          strokeWidth={strokeWidth}
          fill="transparent"
        />
        <G>
          {segments.map((segment, index) => (
            <Circle
              key={index}
              cx={center}
              cy={center}
              r={radius}
              stroke={segment.color}
              strokeWidth={strokeWidth}
              strokeDasharray={segment.strokeDasharray}
              strokeLinecap="round"
              fill="transparent"
              transform={`rotate(${segment.rotation} ${center} ${center})`}
            />
          ))}
        </G>
      </Svg>
      {(centerLabel || centerValue) ? (
        <View style={[styles.centerContent, { width: size, height: size }]}>
          {centerLabel ? (
            <ThemedText style={[styles.centerLabel, { color: theme.textSecondary }]}>
              {centerLabel}
            </ThemedText>
          ) : null}
          {centerValue ? (
            <ThemedText style={styles.centerValue}>{centerValue}</ThemedText>
          ) : null}
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: "relative",
  },
  centerContent: {
    position: "absolute",
    top: 0,
    left: 0,
    alignItems: "center",
    justifyContent: "center",
  },
  centerLabel: {
    fontSize: 12,
    fontWeight: "500",
  },
  centerValue: {
    fontSize: 24,
    fontWeight: "700",
    marginTop: 4,
  },
});
