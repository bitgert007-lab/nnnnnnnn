import AsyncStorage from "@react-native-async-storage/async-storage";
import { Expense, Category, Budget, User, UserPreferences } from "@/types";
import { CategoryColors } from "@/constants/theme";

const KEYS = {
  USER: "@expense_user",
  EXPENSES: "@expense_expenses",
  CATEGORIES: "@expense_categories",
  BUDGET: "@expense_budget",
  PREFERENCES: "@expense_preferences",
};

const DEFAULT_CATEGORIES: Category[] = [
  { id: "food", name: "Food", icon: "coffee", color: CategoryColors.food, isCustom: false },
  { id: "transport", name: "Transport", icon: "truck", color: CategoryColors.transport, isCustom: false },
  { id: "shopping", name: "Shopping", icon: "shopping-cart", color: CategoryColors.shopping, isCustom: false },
  { id: "bills", name: "Bills", icon: "file-text", color: CategoryColors.bills, isCustom: false },
  { id: "entertainment", name: "Entertainment", icon: "film", color: CategoryColors.entertainment, isCustom: false },
  { id: "healthcare", name: "Healthcare", icon: "heart", color: CategoryColors.healthcare, isCustom: false },
  { id: "housing", name: "Housing", icon: "home", color: CategoryColors.housing, isCustom: false },
  { id: "others", name: "Others", icon: "more-horizontal", color: CategoryColors.others, isCustom: false },
];

const DEFAULT_PREFERENCES: UserPreferences = {
  currency: "USD",
  darkMode: true,
  notifications: true,
};

export async function getUser(): Promise<User | null> {
  try {
    const data = await AsyncStorage.getItem(KEYS.USER);
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
}

export async function saveUser(user: User): Promise<void> {
  await AsyncStorage.setItem(KEYS.USER, JSON.stringify(user));
}

export async function removeUser(): Promise<void> {
  await AsyncStorage.removeItem(KEYS.USER);
}

export async function getExpenses(): Promise<Expense[]> {
  try {
    const data = await AsyncStorage.getItem(KEYS.EXPENSES);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export async function saveExpenses(expenses: Expense[]): Promise<void> {
  await AsyncStorage.setItem(KEYS.EXPENSES, JSON.stringify(expenses));
}

export async function addExpense(expense: Expense): Promise<void> {
  const expenses = await getExpenses();
  expenses.unshift(expense);
  await saveExpenses(expenses);
}

export async function updateExpense(expense: Expense): Promise<void> {
  const expenses = await getExpenses();
  const index = expenses.findIndex((e) => e.id === expense.id);
  if (index !== -1) {
    expenses[index] = expense;
    await saveExpenses(expenses);
  }
}

export async function deleteExpense(id: string): Promise<void> {
  const expenses = await getExpenses();
  const filtered = expenses.filter((e) => e.id !== id);
  await saveExpenses(filtered);
}

export async function getCategories(): Promise<Category[]> {
  try {
    const data = await AsyncStorage.getItem(KEYS.CATEGORIES);
    if (data) {
      return JSON.parse(data);
    }
    await AsyncStorage.setItem(KEYS.CATEGORIES, JSON.stringify(DEFAULT_CATEGORIES));
    return DEFAULT_CATEGORIES;
  } catch {
    return DEFAULT_CATEGORIES;
  }
}

export async function saveCategories(categories: Category[]): Promise<void> {
  await AsyncStorage.setItem(KEYS.CATEGORIES, JSON.stringify(categories));
}

export async function addCategory(category: Category): Promise<void> {
  const categories = await getCategories();
  categories.push(category);
  await saveCategories(categories);
}

export async function getBudget(): Promise<Budget | null> {
  try {
    const data = await AsyncStorage.getItem(KEYS.BUDGET);
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
}

export async function saveBudget(budget: Budget): Promise<void> {
  await AsyncStorage.setItem(KEYS.BUDGET, JSON.stringify(budget));
}

export async function getPreferences(): Promise<UserPreferences> {
  try {
    const data = await AsyncStorage.getItem(KEYS.PREFERENCES);
    return data ? JSON.parse(data) : DEFAULT_PREFERENCES;
  } catch {
    return DEFAULT_PREFERENCES;
  }
}

export async function savePreferences(preferences: UserPreferences): Promise<void> {
  await AsyncStorage.setItem(KEYS.PREFERENCES, JSON.stringify(preferences));
}

export async function clearAllData(): Promise<void> {
  await AsyncStorage.multiRemove([
    KEYS.USER,
    KEYS.EXPENSES,
    KEYS.CATEGORIES,
    KEYS.BUDGET,
    KEYS.PREFERENCES,
  ]);
}

export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}
