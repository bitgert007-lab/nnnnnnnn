import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from "react";
import { Expense, Category, Budget, UserPreferences } from "@/types";
import * as storage from "@/lib/storage";
import { Currencies } from "@/constants/theme";

interface ExpenseContextType {
  expenses: Expense[];
  categories: Category[];
  budget: Budget | null;
  preferences: UserPreferences;
  isLoading: boolean;
  addExpense: (expense: Omit<Expense, "id">) => Promise<void>;
  updateExpense: (expense: Expense) => Promise<void>;
  deleteExpense: (id: string) => Promise<void>;
  addCategory: (category: Omit<Category, "id" | "isCustom">) => Promise<void>;
  setBudget: (budget: Omit<Budget, "id">) => Promise<void>;
  updatePreferences: (prefs: Partial<UserPreferences>) => Promise<void>;
  refreshData: () => Promise<void>;
  getCurrencySymbol: () => string;
  getMonthlyTotal: (type?: "expense" | "income") => number;
  getCategoryTotal: (categoryId: string) => number;
}

const ExpenseContext = createContext<ExpenseContextType | undefined>(undefined);

export function ExpenseProvider({ children }: { children: ReactNode }) {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [budget, setBudgetState] = useState<Budget | null>(null);
  const [preferences, setPreferences] = useState<UserPreferences>({
    currency: "USD",
    darkMode: true,
    notifications: true,
  });
  const [isLoading, setIsLoading] = useState(true);

  const refreshData = useCallback(async () => {
    setIsLoading(true);
    const [loadedExpenses, loadedCategories, loadedBudget, loadedPrefs] = await Promise.all([
      storage.getExpenses(),
      storage.getCategories(),
      storage.getBudget(),
      storage.getPreferences(),
    ]);
    setExpenses(loadedExpenses);
    setCategories(loadedCategories);
    setBudgetState(loadedBudget);
    setPreferences(loadedPrefs);
    setIsLoading(false);
  }, []);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  async function addExpense(expenseData: Omit<Expense, "id">) {
    const expense: Expense = {
      ...expenseData,
      id: storage.generateId(),
    };
    await storage.addExpense(expense);
    setExpenses((prev) => [expense, ...prev]);
  }

  async function updateExpense(expense: Expense) {
    await storage.updateExpense(expense);
    setExpenses((prev) => prev.map((e) => (e.id === expense.id ? expense : e)));
  }

  async function deleteExpense(id: string) {
    await storage.deleteExpense(id);
    setExpenses((prev) => prev.filter((e) => e.id !== id));
  }

  async function addCategory(categoryData: Omit<Category, "id" | "isCustom">) {
    const category: Category = {
      ...categoryData,
      id: storage.generateId(),
      isCustom: true,
    };
    await storage.addCategory(category);
    setCategories((prev) => [...prev, category]);
  }

  async function setBudget(budgetData: Omit<Budget, "id">) {
    const newBudget: Budget = {
      ...budgetData,
      id: storage.generateId(),
    };
    await storage.saveBudget(newBudget);
    setBudgetState(newBudget);
  }

  async function updatePreferences(prefs: Partial<UserPreferences>) {
    const updated = { ...preferences, ...prefs };
    await storage.savePreferences(updated);
    setPreferences(updated);
  }

  function getCurrencySymbol(): string {
    const currency = Currencies.find((c) => c.code === preferences.currency);
    return currency?.symbol || "$";
  }

  function getMonthlyTotal(type?: "expense" | "income"): number {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    return expenses
      .filter((e) => {
        const date = new Date(e.date);
        const matchesMonth = date.getMonth() === currentMonth && date.getFullYear() === currentYear;
        const matchesType = type ? e.type === type : true;
        return matchesMonth && matchesType;
      })
      .reduce((sum, e) => sum + e.amount, 0);
  }

  function getCategoryTotal(categoryId: string): number {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    return expenses
      .filter((e) => {
        const date = new Date(e.date);
        return (
          e.categoryId === categoryId &&
          e.type === "expense" &&
          date.getMonth() === currentMonth &&
          date.getFullYear() === currentYear
        );
      })
      .reduce((sum, e) => sum + e.amount, 0);
  }

  return (
    <ExpenseContext.Provider
      value={{
        expenses,
        categories,
        budget,
        preferences,
        isLoading,
        addExpense,
        updateExpense,
        deleteExpense,
        addCategory,
        setBudget,
        updatePreferences,
        refreshData,
        getCurrencySymbol,
        getMonthlyTotal,
        getCategoryTotal,
      }}
    >
      {children}
    </ExpenseContext.Provider>
  );
}

export function useExpenses() {
  const context = useContext(ExpenseContext);
  if (!context) {
    throw new Error("useExpenses must be used within ExpenseProvider");
  }
  return context;
}
