import React, { useState, useEffect } from "react";
import {
  View,
  StyleSheet,
  ScrollView,
  Pressable,
  TextInput,
  Modal,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useNavigation, useRoute, RouteProp } from "@react-navigation/native";
import type { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { ThemedText } from "@/components/ThemedText";
import { CategoryIcon } from "@/components/CategoryIcon";
import { useTheme } from "@/hooks/useTheme";
import { useExpenses } from "@/context/ExpenseContext";
import { Spacing, BorderRadius } from "@/constants/theme";
import type { RootStackParamList } from "@/navigation/RootStackNavigator";
import type { Expense } from "@/types";

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;
type AddExpenseRouteProp = RouteProp<RootStackParamList, "EditExpense">;

const NUMERIC_KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", ".", "0", "del"];

export default function AddExpenseScreen() {
  const insets = useSafeAreaInsets();
  const { theme } = useTheme();
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute<AddExpenseRouteProp>();
  const {
    categories,
    expenses,
    addExpense,
    updateExpense,
    deleteExpense,
    getCurrencySymbol,
  } = useExpenses();

  const expenseId = route.params?.expenseId;
  const isEditing = !!expenseId;
  const existingExpense = expenses.find((e) => e.id === expenseId);

  const [amount, setAmount] = useState(existingExpense?.amount.toString() || "0");
  const [selectedCategory, setSelectedCategory] = useState(
    existingExpense?.categoryId || categories[0]?.id || "food"
  );
  const [description, setDescription] = useState(existingExpense?.description || "");
  const [selectedDate, setSelectedDate] = useState(
    existingExpense?.date ? new Date(existingExpense.date) : new Date()
  );
  const [isIncome, setIsIncome] = useState(existingExpense?.type === "income");
  const [isRecurring, setIsRecurring] = useState(existingExpense?.isRecurring || false);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const currencySymbol = getCurrencySymbol();

  const handleKeyPress = (key: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    if (key === "del") {
      setAmount((prev) => (prev.length > 1 ? prev.slice(0, -1) : "0"));
      return;
    }

    if (key === "." && amount.includes(".")) return;

    const decimalParts = amount.split(".");
    if (decimalParts[1]?.length >= 2) return;

    if (amount === "0" && key !== ".") {
      setAmount(key);
    } else {
      setAmount((prev) => prev + key);
    }
  };

  const handleSave = async () => {
    const numericAmount = parseFloat(amount);
    if (numericAmount <= 0) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      return;
    }

    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

    const expenseData: Omit<Expense, "id"> = {
      amount: numericAmount,
      categoryId: selectedCategory,
      description: description || categories.find((c) => c.id === selectedCategory)?.name || "Expense",
      date: selectedDate.toISOString(),
      type: isIncome ? "income" : "expense",
      isRecurring,
      currency: getCurrencySymbol(),
    };

    if (isEditing && existingExpense) {
      await updateExpense({ ...expenseData, id: existingExpense.id });
    } else {
      await addExpense(expenseData);
    }

    navigation.goBack();
  };

  const handleDelete = async () => {
    if (expenseId) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      await deleteExpense(expenseId);
      navigation.goBack();
    }
  };

  const formatDate = (date: Date) => {
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) return "Today";
    if (date.toDateString() === yesterday.toDateString()) return "Yesterday";
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  };

  const selectDateOption = (option: "today" | "yesterday" | "custom") => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const today = new Date();
    if (option === "today") {
      setSelectedDate(today);
    } else if (option === "yesterday") {
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      setSelectedDate(yesterday);
    }
    setShowDatePicker(false);
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <View style={[styles.header, { paddingTop: insets.top + Spacing.md }]}>
        <Pressable onPress={() => navigation.goBack()} style={styles.closeButton}>
          <Feather name="x" size={24} color={theme.text} />
        </Pressable>
        <ThemedText style={styles.headerTitle}>
          {isEditing ? "EDIT EXPENSE" : "ADD EXPENSE"}
        </ThemedText>
        {isEditing ? (
          <Pressable onPress={() => setShowDeleteConfirm(true)} style={styles.deleteButton}>
            <Feather name="trash-2" size={22} color={theme.error} />
          </Pressable>
        ) : (
          <View style={styles.placeholder} />
        )}
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.amountSection}>
          <View style={styles.typeToggle}>
            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setIsIncome(false);
              }}
              style={[
                styles.typeButton,
                !isIncome && { backgroundColor: theme.error + "20" },
              ]}
            >
              <ThemedText style={{ color: isIncome ? theme.textSecondary : theme.error }}>
                Expense
              </ThemedText>
            </Pressable>
            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setIsIncome(true);
              }}
              style={[
                styles.typeButton,
                isIncome && { backgroundColor: theme.success + "20" },
              ]}
            >
              <ThemedText style={{ color: isIncome ? theme.success : theme.textSecondary }}>
                Income
              </ThemedText>
            </Pressable>
          </View>

          <ThemedText style={styles.amountDisplay}>
            <ThemedText style={[styles.currencySymbol, { color: theme.textSecondary }]}>
              {currencySymbol}
            </ThemedText>
            {amount}
          </ThemedText>
        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoriesContainer}
        >
          {categories.map((category) => (
            <Pressable
              key={category.id}
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setSelectedCategory(category.id);
              }}
              style={[
                styles.categoryButton,
                selectedCategory === category.id && {
                  backgroundColor: category.color,
                },
              ]}
            >
              <View
                style={[
                  styles.categoryIconContainer,
                  {
                    backgroundColor:
                      selectedCategory === category.id
                        ? "rgba(255, 255, 255, 0.2)"
                        : theme.backgroundSecondary,
                  },
                ]}
              >
                <Feather
                  name={category.icon as any}
                  size={24}
                  color={selectedCategory === category.id ? "#fff" : category.color}
                />
              </View>
              <ThemedText
                style={[
                  styles.categoryLabel,
                  { color: selectedCategory === category.id ? "#fff" : theme.textSecondary },
                ]}
              >
                {category.name}
              </ThemedText>
            </Pressable>
          ))}
        </ScrollView>

        <View style={styles.optionsRow}>
          <Pressable
            onPress={() => setShowDatePicker(true)}
            style={[styles.optionButton, { backgroundColor: theme.backgroundSecondary }]}
          >
            <Feather name="calendar" size={18} color={theme.primary} />
            <ThemedText style={styles.optionText}>{formatDate(selectedDate)}</ThemedText>
          </Pressable>

          <View style={[styles.noteInput, { backgroundColor: theme.backgroundSecondary }]}>
            <Feather name="edit-2" size={18} color={theme.textSecondary} />
            <TextInput
              style={[styles.noteTextInput, { color: theme.text }]}
              placeholder="Add a note..."
              placeholderTextColor={theme.textSecondary}
              value={description}
              onChangeText={setDescription}
            />
          </View>
        </View>

        <Pressable
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            setIsRecurring(!isRecurring);
          }}
          style={[styles.recurringButton, { backgroundColor: theme.backgroundSecondary }]}
        >
          <Feather
            name={isRecurring ? "check-square" : "square"}
            size={20}
            color={isRecurring ? theme.primary : theme.textSecondary}
          />
          <ThemedText style={styles.recurringText}>Recurring expense</ThemedText>
        </Pressable>
      </ScrollView>

      <View style={[styles.keypadContainer, { backgroundColor: theme.backgroundDefault }]}>
        <View style={styles.keypad}>
          {NUMERIC_KEYS.map((key) => (
            <Pressable
              key={key}
              onPress={() => handleKeyPress(key)}
              style={({ pressed }) => [
                styles.keypadButton,
                { opacity: pressed ? 0.6 : 1 },
              ]}
            >
              {key === "del" ? (
                <Feather name="delete" size={24} color={theme.text} />
              ) : (
                <ThemedText style={styles.keypadText}>{key}</ThemedText>
              )}
            </Pressable>
          ))}
        </View>

        <Pressable
          onPress={handleSave}
          style={({ pressed }) => [
            styles.saveButton,
            {
              backgroundColor: theme.primary,
              marginBottom: insets.bottom + Spacing.md,
              opacity: pressed ? 0.8 : 1,
            },
          ]}
        >
          <ThemedText style={[styles.saveButtonText, { color: theme.buttonText }]}>
            {isEditing ? "Update Expense" : "Save Expense"}
          </ThemedText>
        </Pressable>
      </View>

      <Modal
        visible={showDatePicker}
        transparent
        animationType="fade"
        onRequestClose={() => setShowDatePicker(false)}
      >
        <Pressable
          style={styles.modalOverlay}
          onPress={() => setShowDatePicker(false)}
        >
          <View style={[styles.datePickerContent, { backgroundColor: theme.backgroundDefault }]}>
            <ThemedText style={styles.datePickerTitle}>Select Date</ThemedText>
            <Pressable
              onPress={() => selectDateOption("today")}
              style={[styles.dateOption, { backgroundColor: theme.backgroundSecondary }]}
            >
              <ThemedText>Today</ThemedText>
            </Pressable>
            <Pressable
              onPress={() => selectDateOption("yesterday")}
              style={[styles.dateOption, { backgroundColor: theme.backgroundSecondary }]}
            >
              <ThemedText>Yesterday</ThemedText>
            </Pressable>
          </View>
        </Pressable>
      </Modal>

      <Modal
        visible={showDeleteConfirm}
        transparent
        animationType="fade"
        onRequestClose={() => setShowDeleteConfirm(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.deleteConfirmContent, { backgroundColor: theme.backgroundDefault }]}>
            <ThemedText style={styles.deleteConfirmTitle}>Delete Expense?</ThemedText>
            <ThemedText style={[styles.deleteConfirmText, { color: theme.textSecondary }]}>
              This action cannot be undone.
            </ThemedText>
            <View style={styles.deleteConfirmButtons}>
              <Pressable
                onPress={() => setShowDeleteConfirm(false)}
                style={[styles.deleteConfirmButton, { backgroundColor: theme.backgroundSecondary }]}
              >
                <ThemedText>Cancel</ThemedText>
              </Pressable>
              <Pressable
                onPress={handleDelete}
                style={[styles.deleteConfirmButton, { backgroundColor: theme.error }]}
              >
                <ThemedText style={{ color: "#fff" }}>Delete</ThemedText>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  closeButton: {
    width: 40,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
  },
  headerTitle: {
    fontSize: 14,
    fontWeight: "600",
    letterSpacing: 1,
  },
  deleteButton: {
    width: 40,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
  },
  placeholder: {
    width: 40,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
  },
  amountSection: {
    alignItems: "center",
    paddingVertical: Spacing.xl,
  },
  typeToggle: {
    flexDirection: "row",
    gap: Spacing.sm,
    marginBottom: Spacing.lg,
  },
  typeButton: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
  },
  amountDisplay: {
    fontSize: 48,
    fontWeight: "700",
  },
  currencySymbol: {
    fontSize: 32,
  },
  categoriesContainer: {
    paddingVertical: Spacing.md,
    gap: Spacing.sm,
  },
  categoryButton: {
    alignItems: "center",
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    marginRight: Spacing.sm,
    minWidth: 80,
  },
  categoryIconContainer: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.sm,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.xs,
  },
  categoryLabel: {
    fontSize: 12,
    fontWeight: "500",
  },
  optionsRow: {
    flexDirection: "row",
    gap: Spacing.sm,
    marginTop: Spacing.lg,
  },
  optionButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.sm,
  },
  optionText: {
    fontSize: 14,
    fontWeight: "500",
  },
  noteInput: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    paddingHorizontal: Spacing.lg,
    borderRadius: BorderRadius.sm,
  },
  noteTextInput: {
    flex: 1,
    fontSize: 14,
    paddingVertical: Spacing.md,
  },
  recurringButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.sm,
    marginTop: Spacing.sm,
    alignSelf: "flex-start",
  },
  recurringText: {
    fontSize: 14,
  },
  keypadContainer: {
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.lg,
    borderTopLeftRadius: BorderRadius.lg,
    borderTopRightRadius: BorderRadius.lg,
  },
  keypad: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    marginBottom: Spacing.lg,
  },
  keypadButton: {
    width: "30%",
    aspectRatio: 2,
    alignItems: "center",
    justifyContent: "center",
  },
  keypadText: {
    fontSize: 28,
    fontWeight: "500",
  },
  saveButton: {
    height: Spacing.buttonHeight,
    borderRadius: BorderRadius.full,
    alignItems: "center",
    justifyContent: "center",
  },
  saveButtonText: {
    fontSize: 18,
    fontWeight: "600",
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
    padding: Spacing.lg,
  },
  datePickerContent: {
    width: "100%",
    padding: Spacing.xl,
    borderRadius: BorderRadius.md,
    gap: Spacing.md,
  },
  datePickerTitle: {
    fontSize: 18,
    fontWeight: "600",
    textAlign: "center",
    marginBottom: Spacing.md,
  },
  dateOption: {
    padding: Spacing.lg,
    borderRadius: BorderRadius.sm,
    alignItems: "center",
  },
  deleteConfirmContent: {
    width: "100%",
    padding: Spacing.xl,
    borderRadius: BorderRadius.md,
    alignItems: "center",
  },
  deleteConfirmTitle: {
    fontSize: 20,
    fontWeight: "600",
    marginBottom: Spacing.sm,
  },
  deleteConfirmText: {
    fontSize: 14,
    marginBottom: Spacing.xl,
  },
  deleteConfirmButtons: {
    flexDirection: "row",
    gap: Spacing.md,
    width: "100%",
  },
  deleteConfirmButton: {
    flex: 1,
    height: Spacing.buttonHeight,
    borderRadius: BorderRadius.sm,
    alignItems: "center",
    justifyContent: "center",
  },
});
