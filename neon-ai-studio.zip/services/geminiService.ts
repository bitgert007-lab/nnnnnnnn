import { GoogleGenAI } from "@google/genai";
import { GenerationSettings } from "../types";
import { MODEL_STANDARD, MODEL_HD, STYLE_OPTIONS, PROMPT_ENHANCERS } from "../constants";

// Initialize the API client
// Note: In a real production app, you might proxy this through a backend to protect the key.
// For this demo/landing page, we assume process.env.API_KEY is available.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateImage = async (
  prompt: string,
  settings: GenerationSettings
): Promise<string> => {
  try {
    if (!process.env.API_KEY) {
      throw new Error("API Key is missing. Please check your environment variables.");
    }

    // Select model based on quality setting
    const modelName = settings.quality === 'hd' ? MODEL_HD : MODEL_STANDARD;

    // Enhance prompt
    const selectedStyle = STYLE_OPTIONS.find(s => s.id === settings.style);
    const styleModifier = selectedStyle ? selectedStyle.promptModifier : '';
    const fullPrompt = `${prompt}, ${styleModifier}, ${PROMPT_ENHANCERS}`;

    console.log(`Generating with model: ${modelName}`);
    console.log(`Full prompt: ${fullPrompt}`);

    const response = await ai.models.generateContent({
      model: modelName,
      contents: {
        parts: [
          {
            text: fullPrompt,
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: settings.aspectRatio,
          // imageSize is only supported on pro models
          ...(settings.quality === 'hd' ? { imageSize: "2K" } : {}),
        },
      },
    });

    // Parse Response
    if (response.candidates && response.candidates.length > 0) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          const base64String = part.inlineData.data;
          // Return valid Data URI
          return `data:image/png;base64,${base64String}`;
        }
      }
    }

    throw new Error("No image data found in response.");
  } catch (error) {
    console.error("Gemini Image Generation Error:", error);
    throw error;
  }
};
