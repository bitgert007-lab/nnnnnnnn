import React from "react";
import { View, Pressable, StyleSheet } from "react-native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { Feather } from "@expo/vector-icons";

import HomeScreen from "@/screens/HomeScreen";
import { ThemedText } from "@/components/ThemedText";
import { useScreenOptions } from "@/hooks/useScreenOptions";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/context/AuthContext";
import { Spacing } from "@/constants/theme";

export type HomeStackParamList = {
  Home: undefined;
};

const Stack = createNativeStackNavigator<HomeStackParamList>();

function HomeHeader() {
  const { theme } = useTheme();
  const { user } = useAuth();

  const currentMonth = new Date().toLocaleDateString("en-US", {
    month: "short",
    year: "numeric",
  });

  return (
    <View style={styles.headerContainer}>
      <View style={styles.headerLeft}>
        <View style={[styles.avatar, { backgroundColor: theme.primary }]}>
          <ThemedText style={[styles.avatarText, { color: theme.buttonText }]}>
            {user?.name?.charAt(0).toUpperCase() || "U"}
          </ThemedText>
        </View>
        <View>
          <ThemedText style={[styles.welcomeText, { color: theme.textSecondary }]}>
            Welcome back
          </ThemedText>
          <ThemedText style={styles.userName}>{user?.name || "User"}</ThemedText>
        </View>
      </View>
      <View style={styles.headerRight}>
        <Pressable style={[styles.monthSelector, { backgroundColor: theme.backgroundSecondary }]}>
          <ThemedText style={styles.monthText}>{currentMonth}</ThemedText>
          <Feather name="chevron-down" size={16} color={theme.text} />
        </Pressable>
        <Pressable style={[styles.notificationButton, { backgroundColor: theme.backgroundSecondary }]}>
          <Feather name="bell" size={20} color={theme.text} />
        </Pressable>
      </View>
    </View>
  );
}

export default function HomeStackNavigator() {
  const screenOptions = useScreenOptions();

  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen
        name="Home"
        component={HomeScreen}
        options={{
          headerTitle: () => <HomeHeader />,
          headerTitleAlign: "left",
        }}
      />
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    width: "100%",
    paddingRight: Spacing.lg,
  },
  headerLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarText: {
    fontSize: 16,
    fontWeight: "600",
  },
  welcomeText: {
    fontSize: 12,
  },
  userName: {
    fontSize: 16,
    fontWeight: "600",
  },
  headerRight: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  monthSelector: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: 20,
  },
  monthText: {
    fontSize: 14,
    fontWeight: "500",
  },
  notificationButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
});
