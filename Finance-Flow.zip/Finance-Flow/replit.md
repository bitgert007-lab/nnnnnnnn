# ExpenseTracker - Personal Finance Management App

## Overview
ExpenseTracker is a cross-platform mobile expense management application built with React Native (Expo) and Express.js. It helps users track expenses, manage budgets, and gain insights into their spending habits with support for multiple currencies.

## Tech Stack
- **Frontend**: React Native with Expo
- **Backend**: Express.js with TypeScript
- **Navigation**: React Navigation 7+
- **State Management**: React Context + React Query
- **Storage**: AsyncStorage for local persistence
- **Styling**: Custom theme system with dark mode support

## Project Structure
```
├── client/                 # React Native Expo app
│   ├── App.tsx            # Root component with providers
│   ├── components/        # Reusable UI components
│   ├── constants/theme.ts # Colors, spacing, typography
│   ├── context/           # Auth and Expense contexts
│   ├── hooks/             # Custom React hooks
│   ├── lib/               # Utilities (storage, API client)
│   ├── navigation/        # Stack and tab navigators
│   ├── screens/           # App screens
│   └── types/             # TypeScript type definitions
├── server/                # Express.js backend
├── shared/                # Shared types/schemas
└── assets/               # Images and static files
```

## Key Features
1. **User Authentication**: Email/password login with local storage
2. **Expense Tracking**: Add, edit, delete expenses with categories
3. **Budget Management**: Set monthly limits with alerts
4. **Analytics**: Spending trends with charts and reports
5. **Multi-Currency**: Support for USD, PKR, INR, EUR, GBP, AED
6. **Dark Mode**: Rich dark green theme

## Running the App
- **Frontend**: `npm run expo:dev` (port 8081)
- **Backend**: `npm run server:dev` (port 5000)

## Design Guidelines
The app follows a dark green aesthetic with:
- Primary color: #4ADE80 (bright green)
- Background: #0D1F17 (deep dark green)
- Category colors for easy identification

See `design_guidelines.md` for complete design specifications.

## Recent Changes
- Initial MVP implementation with full expense tracking
- Added budget management with category limits
- Implemented spending analytics with charts
- Added multi-currency support
- Created dark green themed UI matching provided designs
