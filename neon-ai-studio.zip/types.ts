export interface GeneratedImage {
  id: string;
  url: string;
  prompt: string;
  style: string;
  aspectRatio: string;
  timestamp: number;
  model: string;
}

export type AspectRatio = '1:1' | '16:9' | '9:16' | '4:3' | '3:4';

export interface GenerationSettings {
  style: string;
  aspectRatio: AspectRatio;
  quality: 'standard' | 'hd';
}

export interface PromptHistoryItem {
  id: string;
  text: string;
  timestamp: number;
}

export interface StyleOption {
  id: string;
  label: string;
  promptModifier: string;
}
