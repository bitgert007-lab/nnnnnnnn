import React, { useMemo } from "react";
import {
  View,
  StyleSheet,
  ScrollView,
  Pressable,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import type { NativeStackNavigationProp } from "@react-navigation/native-stack";

import { ThemedText } from "@/components/ThemedText";
import { DonutChart } from "@/components/DonutChart";
import { ProgressBar } from "@/components/ProgressBar";
import { TransactionCard } from "@/components/TransactionCard";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/context/AuthContext";
import { useExpenses } from "@/context/ExpenseContext";
import { Spacing, BorderRadius, CategoryColors } from "@/constants/theme";
import type { RootStackParamList } from "@/navigation/RootStackNavigator";

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();
  const { user } = useAuth();
  const navigation = useNavigation<NavigationProp>();
  const {
    expenses,
    categories,
    budget,
    isLoading,
    getCurrencySymbol,
    getMonthlyTotal,
    getCategoryTotal,
  } = useExpenses();

  const currencySymbol = getCurrencySymbol();
  const monthlyExpense = getMonthlyTotal("expense");
  const monthlyIncome = getMonthlyTotal("income");
  const budgetLimit = budget?.monthlyLimit || 2000;
  const remaining = Math.max(budgetLimit - monthlyExpense, 0);
  const budgetProgress = budgetLimit > 0 ? monthlyExpense / budgetLimit : 0;

  const currentMonth = new Date().toLocaleDateString("en-US", {
    month: "short",
    year: "numeric",
  });

  const categoryBreakdown = useMemo(() => {
    const breakdown: { [key: string]: number } = {};
    const now = new Date();
    const currentMonthNum = now.getMonth();
    const currentYear = now.getFullYear();

    expenses.forEach((expense) => {
      if (expense.type !== "expense") return;
      const date = new Date(expense.date);
      if (date.getMonth() === currentMonthNum && date.getFullYear() === currentYear) {
        breakdown[expense.categoryId] = (breakdown[expense.categoryId] || 0) + expense.amount;
      }
    });

    return Object.entries(breakdown)
      .map(([categoryId, value]) => {
        const category = categories.find((c) => c.id === categoryId);
        return {
          categoryId,
          value,
          color: category?.color || CategoryColors.others,
          label: category?.name || "Other",
        };
      })
      .sort((a, b) => b.value - a.value)
      .slice(0, 4);
  }, [expenses, categories]);

  const topCategory = categoryBreakdown[0]?.label || "None";

  const recentTransactions = useMemo(() => {
    return expenses.slice(0, 4);
  }, [expenses]);

  if (isLoading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: theme.backgroundRoot }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={{
          paddingTop: headerHeight + Spacing.xl,
          paddingBottom: tabBarHeight + Spacing["4xl"],
          paddingHorizontal: Spacing.lg,
        }}
        scrollIndicatorInsets={{ bottom: insets.bottom }}
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.summaryCard, { backgroundColor: theme.backgroundDefault }]}>
          <View style={styles.summaryHeader}>
            <View>
              <ThemedText style={[styles.summaryLabel, { color: theme.textSecondary }]}>
                Total Spent
              </ThemedText>
              <ThemedText style={styles.summaryAmount}>
                {currencySymbol}{monthlyExpense.toFixed(2).split(".")[0]}
                <ThemedText style={[styles.summaryDecimals, { color: theme.textSecondary }]}>
                  .{monthlyExpense.toFixed(2).split(".")[1]}
                </ThemedText>
              </ThemedText>
            </View>
            <View style={styles.remainingContainer}>
              <ThemedText style={[styles.remainingLabel, { color: theme.textSecondary }]}>
                Remaining
              </ThemedText>
              <ThemedText style={[styles.remainingAmount, { color: theme.primary }]}>
                {currencySymbol}{remaining.toFixed(2)}
              </ThemedText>
            </View>
          </View>

          <View style={styles.progressContainer}>
            <View style={styles.progressLabels}>
              <ThemedText style={[styles.progressText, { color: theme.textSecondary }]}>
                {Math.round(budgetProgress * 100)}% used
              </ThemedText>
              <ThemedText style={[styles.progressText, { color: theme.textSecondary }]}>
                {currencySymbol}{budgetLimit.toFixed(0)} Limit
              </ThemedText>
            </View>
            <ProgressBar
              progress={budgetProgress}
              color={budgetProgress > 0.9 ? theme.error : theme.primary}
              height={10}
            />
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <ThemedText style={styles.sectionTitle}>Spending Breakdown</ThemedText>
          <Pressable onPress={() => navigation.navigate("Main", { screen: "StatsTab" } as any)}>
            <ThemedText style={{ color: theme.primary }}>View Report</ThemedText>
          </Pressable>
        </View>

        <View style={[styles.chartCard, { backgroundColor: theme.backgroundDefault }]}>
          {categoryBreakdown.length > 0 ? (
            <View style={styles.chartContainer}>
              <DonutChart
                data={categoryBreakdown}
                size={160}
                strokeWidth={18}
                centerLabel="Top"
                centerValue={topCategory}
              />
              <View style={styles.legend}>
                {categoryBreakdown.map((item, index) => (
                  <View key={index} style={styles.legendItem}>
                    <View style={[styles.legendDot, { backgroundColor: item.color }]} />
                    <ThemedText style={[styles.legendLabel, { color: theme.textSecondary }]}>
                      {item.label.toUpperCase()}
                    </ThemedText>
                    <ThemedText style={styles.legendValue}>
                      {Math.round((item.value / monthlyExpense) * 100)}%
                    </ThemedText>
                  </View>
                ))}
              </View>
            </View>
          ) : (
            <View style={styles.emptyChart}>
              <Feather name="pie-chart" size={48} color={theme.textSecondary} />
              <ThemedText style={[styles.emptyText, { color: theme.textSecondary }]}>
                No expenses this month
              </ThemedText>
            </View>
          )}
        </View>

        <View style={styles.sectionHeader}>
          <ThemedText style={styles.sectionTitle}>Recent Transactions</ThemedText>
          <Pressable onPress={() => navigation.navigate("Main", { screen: "TransactionsTab" } as any)}>
            <ThemedText style={{ color: theme.textSecondary }}>See all</ThemedText>
          </Pressable>
        </View>

        {recentTransactions.length > 0 ? (
          <View style={styles.transactionsList}>
            {recentTransactions.map((expense) => (
              <TransactionCard
                key={expense.id}
                expense={expense}
                category={categories.find((c) => c.id === expense.categoryId)}
                onPress={() => navigation.navigate("EditExpense", { expenseId: expense.id })}
              />
            ))}
          </View>
        ) : (
          <View style={[styles.emptyTransactions, { backgroundColor: theme.backgroundDefault }]}>
            <Feather name="inbox" size={48} color={theme.textSecondary} />
            <ThemedText style={[styles.emptyText, { color: theme.textSecondary }]}>
              No transactions yet
            </ThemedText>
            <ThemedText style={[styles.emptySubtext, { color: theme.textSecondary }]}>
              Tap the + button to add your first expense
            </ThemedText>
          </View>
        )}
      </ScrollView>

      <Pressable
        onPress={() => navigation.navigate("AddExpense")}
        style={({ pressed }) => [
          styles.fab,
          {
            backgroundColor: theme.primary,
            bottom: tabBarHeight + Spacing.lg,
            opacity: pressed ? 0.8 : 1,
            transform: [{ scale: pressed ? 0.95 : 1 }],
          },
        ]}
      >
        <Feather name="plus" size={28} color={theme.buttonText} />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  scrollView: {
    flex: 1,
  },
  summaryCard: {
    padding: Spacing.xl,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.xl,
  },
  summaryHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: Spacing.lg,
  },
  summaryLabel: {
    fontSize: 14,
    marginBottom: 4,
  },
  summaryAmount: {
    fontSize: 32,
    fontWeight: "700",
  },
  summaryDecimals: {
    fontSize: 20,
    fontWeight: "400",
  },
  remainingContainer: {
    alignItems: "flex-end",
  },
  remainingLabel: {
    fontSize: 14,
    marginBottom: 4,
  },
  remainingAmount: {
    fontSize: 20,
    fontWeight: "700",
  },
  progressContainer: {
    gap: Spacing.sm,
  },
  progressLabels: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  progressText: {
    fontSize: 12,
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "600",
  },
  chartCard: {
    padding: Spacing.xl,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.xl,
  },
  chartContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  legend: {
    flex: 1,
    marginLeft: Spacing.xl,
    gap: Spacing.md,
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
  },
  legendDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: Spacing.sm,
  },
  legendLabel: {
    fontSize: 11,
    flex: 1,
  },
  legendValue: {
    fontSize: 14,
    fontWeight: "600",
  },
  emptyChart: {
    alignItems: "center",
    paddingVertical: Spacing["2xl"],
  },
  emptyText: {
    fontSize: 16,
    marginTop: Spacing.md,
  },
  emptySubtext: {
    fontSize: 14,
    marginTop: Spacing.xs,
    textAlign: "center",
  },
  transactionsList: {
    gap: 0,
  },
  emptyTransactions: {
    padding: Spacing["3xl"],
    borderRadius: BorderRadius.md,
    alignItems: "center",
  },
  fab: {
    position: "absolute",
    right: Spacing.lg,
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
});
