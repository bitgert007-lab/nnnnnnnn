import React from "react";
import { Pressable } from "react-native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { Feather } from "@expo/vector-icons";

import TransactionsScreen from "@/screens/TransactionsScreen";
import { ThemedText } from "@/components/ThemedText";
import { useScreenOptions } from "@/hooks/useScreenOptions";
import { useTheme } from "@/hooks/useTheme";

export type TransactionsStackParamList = {
  Transactions: undefined;
};

const Stack = createNativeStackNavigator<TransactionsStackParamList>();

export default function TransactionsStackNavigator() {
  const screenOptions = useScreenOptions();
  const { theme } = useTheme();

  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen
        name="Transactions"
        component={TransactionsScreen}
        options={{
          headerTitle: "Transactions",
          headerRight: () => (
            <Pressable>
              <ThemedText style={{ color: theme.primary }}>Filter</ThemedText>
            </Pressable>
          ),
        }}
      />
    </Stack.Navigator>
  );
}
