import React from "react";
import { View, StyleSheet } from "react-native";
import { Feather } from "@expo/vector-icons";
import { BorderRadius } from "@/constants/theme";

interface CategoryIconProps {
  icon: string;
  color: string;
  size?: number;
}

export function CategoryIcon({ icon, color, size = 48 }: CategoryIconProps) {
  const iconSize = size * 0.5;

  return (
    <View style={[styles.container, { width: size, height: size, backgroundColor: color + "20" }]}>
      <Feather name={icon as any} size={iconSize} color={color} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: BorderRadius.sm,
    alignItems: "center",
    justifyContent: "center",
  },
});
