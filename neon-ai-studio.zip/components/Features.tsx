import React from 'react';
import { Zap, Palette, Lock, Sliders, Smartphone, Gauge } from 'lucide-react';

const Features: React.FC = () => {
  const features = [
    {
      icon: <Zap className="w-6 h-6 text-yellow-500" />,
      title: "Instant Generation",
      desc: "Powered by Gemini 2.5 Flash, generate images in seconds without waiting in queues."
    },
    {
      icon: <Palette className="w-6 h-6 text-pink-500" />,
      title: "Artistic Styles",
      desc: "Choose from over 10 professionally curated styles including Anime, Cinematic, and 3D."
    },
    {
      icon: <Gauge className="w-6 h-6 text-indigo-500" />,
      title: "HD Resolution",
      desc: "Switch to Pro mode for high-definition 2K exports perfect for printing or professional use."
    },
    {
      icon: <Sliders className="w-6 h-6 text-green-500" />,
      title: "Advanced Controls",
      desc: "Fine-tune aspect ratios and prompt enhancers to get exactly what you envisioned."
    },
    {
      icon: <Lock className="w-6 h-6 text-blue-500" />,
      title: "Private & Secure",
      desc: "Your generations are private. History is stored locally on your device."
    },
    {
      icon: <Smartphone className="w-6 h-6 text-purple-500" />,
      title: "Mobile Optimized",
      desc: "Create on the go. The entire studio is fully responsive and touch-friendly."
    }
  ];

  return (
    <div id="features" className="py-24 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-indigo-600/5 dark:bg-indigo-600/10 rounded-full blur-3xl -translate-y-1/2 -translate-x-1/2 pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-display font-bold mb-6 text-slate-900 dark:text-white">
            Everything you need to <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-500 to-pink-500">create</span>
          </h2>
          <p className="text-slate-600 dark:text-gray-400 max-w-2xl mx-auto text-lg">
            Built for creators, by creators. Lumina combines power with simplicity to give you the best AI art experience.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, idx) => (
            <div key={idx} className="glass-panel p-8 rounded-2xl hover:bg-white/50 dark:hover:bg-white/5 transition-colors group shadow-sm dark:shadow-none">
              <div className="w-12 h-12 rounded-lg bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold mb-3 font-display text-slate-900 dark:text-white">{feature.title}</h3>
              <p className="text-slate-600 dark:text-gray-400 leading-relaxed">
                {feature.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Features;