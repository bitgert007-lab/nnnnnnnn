import React, { useState } from "react";
import {
  View,
  StyleSheet,
  ScrollView,
  Pressable,
  Switch,
  Modal,
  FlatList,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/context/AuthContext";
import { useExpenses } from "@/context/ExpenseContext";
import { Spacing, BorderRadius, Currencies } from "@/constants/theme";

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();
  const { user, logout } = useAuth();
  const { preferences, updatePreferences } = useExpenses();

  const [showCurrencyModal, setShowCurrencyModal] = useState(false);

  const currentCurrency = Currencies.find((c) => c.code === preferences.currency) || Currencies[0];

  const handleCurrencySelect = async (code: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    await updatePreferences({ currency: code });
    setShowCurrencyModal(false);
  };

  const handleDarkModeToggle = async (value: boolean) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    await updatePreferences({ darkMode: value });
  };

  const handleNotificationsToggle = async (value: boolean) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    await updatePreferences({ notifications: value });
  };

  const handleLogout = async () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    await logout();
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={{
          paddingTop: headerHeight + Spacing.xl,
          paddingBottom: tabBarHeight + Spacing["2xl"],
          paddingHorizontal: Spacing.lg,
        }}
        scrollIndicatorInsets={{ bottom: insets.bottom }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.profileHeader}>
          <View style={[styles.avatar, { backgroundColor: theme.primary }]}>
            <ThemedText style={[styles.avatarText, { color: theme.buttonText }]}>
              {user?.name?.charAt(0).toUpperCase() || "U"}
            </ThemedText>
          </View>
          <ThemedText style={styles.userName}>{user?.name || "User"}</ThemedText>
          <ThemedText style={[styles.userEmail, { color: theme.textSecondary }]}>
            {user?.email || "email@example.com"}
          </ThemedText>
        </View>

        <View style={styles.section}>
          <ThemedText style={[styles.sectionTitle, { color: theme.textSecondary }]}>
            PREFERENCES
          </ThemedText>

          <View style={[styles.settingsCard, { backgroundColor: theme.backgroundDefault }]}>
            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setShowCurrencyModal(true);
              }}
              style={styles.settingRow}
            >
              <View style={styles.settingLeft}>
                <Feather name="dollar-sign" size={20} color={theme.text} />
                <ThemedText style={styles.settingLabel}>Currency</ThemedText>
              </View>
              <View style={styles.settingRight}>
                <ThemedText style={[styles.settingValue, { color: theme.textSecondary }]}>
                  {currentCurrency.code} ({currentCurrency.symbol})
                </ThemedText>
                <Feather name="chevron-right" size={20} color={theme.textSecondary} />
              </View>
            </Pressable>

            <View style={[styles.divider, { backgroundColor: theme.border }]} />

            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <Feather name="moon" size={20} color={theme.text} />
                <ThemedText style={styles.settingLabel}>Dark Mode</ThemedText>
              </View>
              <Switch
                value={preferences.darkMode}
                onValueChange={handleDarkModeToggle}
                trackColor={{ false: theme.backgroundSecondary, true: theme.primary + "60" }}
                thumbColor={preferences.darkMode ? theme.primary : theme.textSecondary}
              />
            </View>

            <View style={[styles.divider, { backgroundColor: theme.border }]} />

            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <Feather name="bell" size={20} color={theme.text} />
                <ThemedText style={styles.settingLabel}>Notifications</ThemedText>
              </View>
              <Switch
                value={preferences.notifications}
                onValueChange={handleNotificationsToggle}
                trackColor={{ false: theme.backgroundSecondary, true: theme.primary + "60" }}
                thumbColor={preferences.notifications ? theme.primary : theme.textSecondary}
              />
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <ThemedText style={[styles.sectionTitle, { color: theme.textSecondary }]}>
            ABOUT
          </ThemedText>

          <View style={[styles.settingsCard, { backgroundColor: theme.backgroundDefault }]}>
            <Pressable style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <Feather name="shield" size={20} color={theme.text} />
                <ThemedText style={styles.settingLabel}>Privacy Policy</ThemedText>
              </View>
              <Feather name="external-link" size={18} color={theme.textSecondary} />
            </Pressable>

            <View style={[styles.divider, { backgroundColor: theme.border }]} />

            <Pressable style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <Feather name="file-text" size={20} color={theme.text} />
                <ThemedText style={styles.settingLabel}>Terms of Service</ThemedText>
              </View>
              <Feather name="external-link" size={18} color={theme.textSecondary} />
            </Pressable>

            <View style={[styles.divider, { backgroundColor: theme.border }]} />

            <Pressable style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <Feather name="help-circle" size={20} color={theme.text} />
                <ThemedText style={styles.settingLabel}>Help & Support</ThemedText>
              </View>
              <Feather name="external-link" size={18} color={theme.textSecondary} />
            </Pressable>
          </View>
        </View>

        <View style={styles.section}>
          <View style={[styles.settingsCard, { backgroundColor: theme.backgroundDefault }]}>
            <Pressable onPress={handleLogout} style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <Feather name="log-out" size={20} color={theme.error} />
                <ThemedText style={[styles.settingLabel, { color: theme.error }]}>
                  Log Out
                </ThemedText>
              </View>
            </Pressable>
          </View>
        </View>

        <ThemedText style={[styles.version, { color: theme.textSecondary }]}>
          Version 1.0.0
        </ThemedText>
      </ScrollView>

      <Modal
        visible={showCurrencyModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowCurrencyModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: theme.backgroundDefault }]}>
            <View style={styles.modalHeader}>
              <ThemedText style={styles.modalTitle}>Select Currency</ThemedText>
              <Pressable onPress={() => setShowCurrencyModal(false)}>
                <Feather name="x" size={24} color={theme.text} />
              </Pressable>
            </View>
            <FlatList
              data={Currencies}
              keyExtractor={(item) => item.code}
              renderItem={({ item }) => (
                <Pressable
                  onPress={() => handleCurrencySelect(item.code)}
                  style={[
                    styles.currencyItem,
                    item.code === preferences.currency && {
                      backgroundColor: theme.primary + "20",
                    },
                  ]}
                >
                  <View>
                    <ThemedText style={styles.currencyCode}>
                      {item.symbol} {item.code}
                    </ThemedText>
                    <ThemedText style={[styles.currencyName, { color: theme.textSecondary }]}>
                      {item.name}
                    </ThemedText>
                  </View>
                  {item.code === preferences.currency ? (
                    <Feather name="check" size={20} color={theme.primary} />
                  ) : null}
                </Pressable>
              )}
              ItemSeparatorComponent={() => (
                <View style={[styles.divider, { backgroundColor: theme.border }]} />
              )}
            />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  profileHeader: {
    alignItems: "center",
    marginBottom: Spacing["2xl"],
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.md,
  },
  avatarText: {
    fontSize: 32,
    fontWeight: "700",
  },
  userName: {
    fontSize: 24,
    fontWeight: "600",
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 14,
  },
  section: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: "600",
    letterSpacing: 0.5,
    marginBottom: Spacing.sm,
    marginLeft: Spacing.sm,
  },
  settingsCard: {
    borderRadius: BorderRadius.md,
    overflow: "hidden",
  },
  settingRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: Spacing.lg,
  },
  settingLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
  },
  settingRight: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  settingLabel: {
    fontSize: 16,
  },
  settingValue: {
    fontSize: 14,
  },
  divider: {
    height: 1,
    marginHorizontal: Spacing.lg,
  },
  version: {
    fontSize: 12,
    textAlign: "center",
    marginTop: Spacing.md,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "flex-end",
  },
  modalContent: {
    maxHeight: "60%",
    borderTopLeftRadius: BorderRadius.lg,
    borderTopRightRadius: BorderRadius.lg,
    paddingBottom: Spacing["3xl"],
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: Spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255, 255, 255, 0.1)",
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "600",
  },
  currencyItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: Spacing.lg,
  },
  currencyCode: {
    fontSize: 16,
    fontWeight: "600",
  },
  currencyName: {
    fontSize: 13,
    marginTop: 2,
  },
});
