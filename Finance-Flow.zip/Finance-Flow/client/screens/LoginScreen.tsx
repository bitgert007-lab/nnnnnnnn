import React, { useState } from "react";
import {
  View,
  StyleSheet,
  TextInput,
  Pressable,
  ActivityIndicator,
  Image,
  Platform,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { ThemedText } from "@/components/ThemedText";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/context/AuthContext";
import { Spacing, BorderRadius } from "@/constants/theme";

type AuthMode = "login" | "signup";

export default function LoginScreen() {
  const insets = useSafeAreaInsets();
  const { theme } = useTheme();
  const { login, signup } = useAuth();

  const [mode, setMode] = useState<AuthMode>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async () => {
    setError("");
    if (!email || !password) {
      setError("Please fill in all fields");
      return;
    }

    if (mode === "signup" && !name) {
      setError("Please enter your name");
      return;
    }

    setIsLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      const success = mode === "login"
        ? await login(email, password)
        : await signup(email, password, name);

      if (!success) {
        setError("Authentication failed. Please try again.");
      }
    } catch {
      setError("An error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const toggleMode = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setMode(mode === "login" ? "signup" : "login");
    setError("");
  };

  return (
    <LinearGradient
      colors={["#0D1F17", "#142620", "#0D1F17"]}
      style={styles.container}
    >
      <KeyboardAwareScrollViewCompat
        style={styles.scrollView}
        contentContainerStyle={[
          styles.content,
          { paddingTop: insets.top + Spacing["3xl"], paddingBottom: insets.bottom + Spacing["2xl"] },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Image
            source={require("../../assets/images/icon.png")}
            style={styles.logo}
            resizeMode="contain"
          />
          <View style={styles.titleContainer}>
            <ThemedText style={styles.title}>Master Your</ThemedText>
            <ThemedText style={[styles.title, { color: theme.primary }]}>Money</ThemedText>
          </View>
          <ThemedText style={[styles.subtitle, { color: theme.textSecondary }]}>
            Track expenses and budget with ease.{"\n"}Control your wealth today.
          </ThemedText>
        </View>

        <View style={styles.tabContainer}>
          <Pressable
            onPress={() => setMode("login")}
            style={[
              styles.tab,
              mode === "login" && { backgroundColor: theme.primary },
            ]}
          >
            <ThemedText
              style={[
                styles.tabText,
                { color: mode === "login" ? theme.buttonText : theme.text },
              ]}
            >
              Login
            </ThemedText>
          </Pressable>
          <Pressable
            onPress={() => setMode("signup")}
            style={[
              styles.tab,
              mode === "signup" && { backgroundColor: theme.primary },
            ]}
          >
            <ThemedText
              style={[
                styles.tabText,
                { color: mode === "signup" ? theme.buttonText : theme.text },
              ]}
            >
              Sign Up
            </ThemedText>
          </Pressable>
        </View>

        <View style={styles.form}>
          {mode === "signup" ? (
            <View style={styles.inputGroup}>
              <ThemedText style={styles.label}>Full Name</ThemedText>
              <TextInput
                style={[
                  styles.input,
                  { backgroundColor: theme.inputBackground, color: theme.text },
                ]}
                placeholder="John Doe"
                placeholderTextColor={theme.textSecondary}
                value={name}
                onChangeText={setName}
                autoCapitalize="words"
              />
            </View>
          ) : null}

          <View style={styles.inputGroup}>
            <ThemedText style={styles.label}>Email Address</ThemedText>
            <TextInput
              style={[
                styles.input,
                { backgroundColor: theme.inputBackground, color: theme.text },
              ]}
              placeholder="name@example.com"
              placeholderTextColor={theme.textSecondary}
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              autoComplete="email"
            />
          </View>

          <View style={styles.inputGroup}>
            <ThemedText style={styles.label}>Password</ThemedText>
            <View style={styles.passwordContainer}>
              <TextInput
                style={[
                  styles.input,
                  styles.passwordInput,
                  { backgroundColor: theme.inputBackground, color: theme.text },
                ]}
                placeholder="••••••••"
                placeholderTextColor={theme.textSecondary}
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPassword}
                autoCapitalize="none"
              />
              <Pressable
                onPress={() => setShowPassword(!showPassword)}
                style={styles.eyeButton}
              >
                <Feather
                  name={showPassword ? "eye-off" : "eye"}
                  size={20}
                  color={theme.textSecondary}
                />
              </Pressable>
            </View>
          </View>

          {mode === "login" ? (
            <Pressable style={styles.forgotPassword}>
              <ThemedText style={[styles.forgotText, { color: theme.textSecondary }]}>
                Forgot Password?
              </ThemedText>
            </Pressable>
          ) : null}

          {error ? (
            <ThemedText style={[styles.errorText, { color: theme.error }]}>
              {error}
            </ThemedText>
          ) : null}

          <Pressable
            onPress={handleSubmit}
            disabled={isLoading}
            style={({ pressed }) => [
              styles.submitButton,
              { backgroundColor: theme.primary, opacity: pressed ? 0.8 : 1 },
            ]}
          >
            {isLoading ? (
              <ActivityIndicator color={theme.buttonText} />
            ) : (
              <ThemedText style={[styles.submitText, { color: theme.buttonText }]}>
                {mode === "login" ? "Log In" : "Sign Up"}
              </ThemedText>
            )}
          </Pressable>

          {Platform.OS !== "web" ? (
            <Pressable style={styles.faceIdButton}>
              <Feather name="smile" size={20} color={theme.textSecondary} />
              <ThemedText style={[styles.faceIdText, { color: theme.textSecondary }]}>
                Quick login with Face ID
              </ThemedText>
            </Pressable>
          ) : null}

          <View style={styles.divider}>
            <View style={[styles.dividerLine, { backgroundColor: theme.border }]} />
            <ThemedText style={[styles.dividerText, { color: theme.textSecondary }]}>
              Or continue with
            </ThemedText>
            <View style={[styles.dividerLine, { backgroundColor: theme.border }]} />
          </View>

          <View style={styles.socialButtons}>
            <Pressable
              style={[styles.socialButton, { backgroundColor: theme.backgroundDefault }]}
            >
              <ThemedText style={styles.socialButtonText}>Google</ThemedText>
            </Pressable>
            <Pressable
              style={[styles.socialButton, { backgroundColor: theme.backgroundDefault }]}
            >
              <ThemedText style={styles.socialButtonText}>Apple</ThemedText>
            </Pressable>
          </View>
        </View>

        <Pressable onPress={toggleMode} style={styles.switchMode}>
          <ThemedText style={{ color: theme.textSecondary }}>
            {mode === "login" ? "Don't have an account? " : "Already have an account? "}
          </ThemedText>
          <ThemedText style={{ color: theme.primary, fontWeight: "600" }}>
            {mode === "login" ? "Sign up" : "Login"}
          </ThemedText>
        </Pressable>
      </KeyboardAwareScrollViewCompat>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing["2xl"],
  },
  header: {
    alignItems: "center",
    marginBottom: Spacing["3xl"],
  },
  logo: {
    width: 60,
    height: 60,
    marginBottom: Spacing.lg,
  },
  titleContainer: {
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  title: {
    fontSize: 32,
    fontWeight: "700",
    textAlign: "center",
  },
  subtitle: {
    fontSize: 16,
    textAlign: "center",
    lineHeight: 24,
  },
  tabContainer: {
    flexDirection: "row",
    backgroundColor: "rgba(255, 255, 255, 0.05)",
    borderRadius: BorderRadius.full,
    padding: 4,
    marginBottom: Spacing["2xl"],
  },
  tab: {
    flex: 1,
    paddingVertical: Spacing.md,
    alignItems: "center",
    borderRadius: BorderRadius.full,
  },
  tabText: {
    fontSize: 16,
    fontWeight: "600",
  },
  form: {
    gap: Spacing.lg,
  },
  inputGroup: {
    gap: Spacing.sm,
  },
  label: {
    fontSize: 14,
    fontWeight: "500",
  },
  input: {
    height: Spacing.inputHeight,
    borderRadius: BorderRadius.sm,
    paddingHorizontal: Spacing.lg,
    fontSize: 16,
  },
  passwordContainer: {
    position: "relative",
  },
  passwordInput: {
    paddingRight: 50,
  },
  eyeButton: {
    position: "absolute",
    right: Spacing.lg,
    top: 0,
    bottom: 0,
    justifyContent: "center",
  },
  forgotPassword: {
    alignSelf: "flex-end",
  },
  forgotText: {
    fontSize: 14,
  },
  errorText: {
    fontSize: 14,
    textAlign: "center",
  },
  submitButton: {
    height: Spacing.buttonHeight,
    borderRadius: BorderRadius.full,
    alignItems: "center",
    justifyContent: "center",
  },
  submitText: {
    fontSize: 18,
    fontWeight: "600",
  },
  faceIdButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: Spacing.sm,
    paddingVertical: Spacing.md,
  },
  faceIdText: {
    fontSize: 14,
  },
  divider: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
    marginVertical: Spacing.md,
  },
  dividerLine: {
    flex: 1,
    height: 1,
  },
  dividerText: {
    fontSize: 14,
  },
  socialButtons: {
    flexDirection: "row",
    gap: Spacing.md,
  },
  socialButton: {
    flex: 1,
    height: Spacing.buttonHeight,
    borderRadius: BorderRadius.sm,
    alignItems: "center",
    justifyContent: "center",
  },
  socialButtonText: {
    fontSize: 16,
    fontWeight: "500",
  },
  switchMode: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: Spacing["2xl"],
  },
});
