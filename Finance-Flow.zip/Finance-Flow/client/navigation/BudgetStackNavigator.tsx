import React from "react";
import { Pressable } from "react-native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import BudgetScreen from "@/screens/BudgetScreen";
import { ThemedText } from "@/components/ThemedText";
import { useScreenOptions } from "@/hooks/useScreenOptions";
import { useTheme } from "@/hooks/useTheme";

export type BudgetStackParamList = {
  Budget: undefined;
};

const Stack = createNativeStackNavigator<BudgetStackParamList>();

export default function BudgetStackNavigator() {
  const screenOptions = useScreenOptions();
  const { theme } = useTheme();

  const currentMonth = new Date().toLocaleDateString("en-US", { month: "long" });

  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen
        name="Budget"
        component={BudgetScreen}
        options={{
          headerTitle: `${currentMonth} Budget`,
          headerRight: () => (
            <Pressable>
              <ThemedText style={{ color: theme.primary }}>Edit</ThemedText>
            </Pressable>
          ),
        }}
      />
    </Stack.Navigator>
  );
}
