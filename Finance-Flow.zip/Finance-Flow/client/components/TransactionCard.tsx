import React from "react";
import { View, StyleSheet, Pressable } from "react-native";
import { ThemedText } from "@/components/ThemedText";
import { CategoryIcon } from "@/components/CategoryIcon";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius } from "@/constants/theme";
import { Expense, Category } from "@/types";
import { useExpenses } from "@/context/ExpenseContext";
import * as Haptics from "expo-haptics";

interface TransactionCardProps {
  expense: Expense;
  category: Category | undefined;
  onPress?: () => void;
}

export function TransactionCard({ expense, category, onPress }: TransactionCardProps) {
  const { theme } = useTheme();
  const { getCurrencySymbol } = useExpenses();
  const currencySymbol = getCurrencySymbol();

  const formattedDate = new Date(expense.date).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });

  const formattedTime = new Date(expense.date).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
  });

  const isIncome = expense.type === "income";
  const amountColor = isIncome ? theme.income : theme.expense;
  const amountPrefix = isIncome ? "+" : "-";

  const handlePress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    onPress?.();
  };

  return (
    <Pressable
      onPress={handlePress}
      style={({ pressed }) => [
        styles.container,
        { backgroundColor: theme.backgroundDefault, opacity: pressed ? 0.8 : 1 },
      ]}
    >
      <CategoryIcon
        icon={category?.icon || "circle"}
        color={category?.color || theme.textSecondary}
      />
      <View style={styles.content}>
        <ThemedText style={styles.title}>{expense.description}</ThemedText>
        <ThemedText style={[styles.subtitle, { color: theme.textSecondary }]}>
          {category?.name || "Other"} • {expense.isRecurring ? "Auto" : formattedTime}
        </ThemedText>
      </View>
      <ThemedText style={[styles.amount, { color: amountColor }]}>
        {amountPrefix}{currencySymbol}{expense.amount.toFixed(2)}
      </ThemedText>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.sm,
  },
  content: {
    flex: 1,
    marginLeft: Spacing.md,
  },
  title: {
    fontSize: 16,
    fontWeight: "600",
  },
  subtitle: {
    fontSize: 13,
    marginTop: 2,
  },
  amount: {
    fontSize: 16,
    fontWeight: "600",
  },
});
