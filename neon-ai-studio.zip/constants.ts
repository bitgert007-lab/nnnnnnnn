import { StyleOption, AspectRatio } from './types';

export const STYLE_OPTIONS: StyleOption[] = [
  { id: 'realistic', label: 'Photorealistic', promptModifier: 'photorealistic, 8k, highly detailed, realistic lighting, photography' },
  { id: 'cinematic', label: 'Cinematic', promptModifier: 'cinematic shot, dramatic lighting, movie scene, color graded, shallow depth of field, 35mm' },
  { id: 'anime', label: 'Anime', promptModifier: 'anime style, studio ghibli, makoto shinkai, vibrant colors, detailed background' },
  { id: 'cyberpunk', label: 'Cyberpunk', promptModifier: 'cyberpunk, neon lights, futuristic city, high tech, synthwave colors, night time' },
  { id: '3d', label: '3D Render', promptModifier: '3d render, unreal engine 5, octane render, ray tracing, plastic texture, clay render' },
  { id: 'illustration', label: 'Illustration', promptModifier: 'digital illustration, vector art, flat design, clean lines, behance, dribbble' },
  { id: 'watercolor', label: 'Watercolor', promptModifier: 'watercolor painting, artistic, soft edges, paper texture, wet on wet, pastel colors' },
  { id: 'fantasy', label: 'Dark Fantasy', promptModifier: 'dark fantasy, oil painting, detailed armor, magic, ethereal, mist, greg rutkowski' },
];

export const ASPECT_RATIOS: { value: AspectRatio; label: string; icon: string }[] = [
  { value: '1:1', label: 'Square', icon: 'square' },
  { value: '16:9', label: 'Landscape', icon: 'rectangle-horizontal' },
  { value: '9:16', label: 'Portrait', icon: 'rectangle-vertical' },
  { value: '4:3', label: 'Classic', icon: 'tv' },
];

export const MODEL_STANDARD = 'gemini-2.5-flash-image';
export const MODEL_HD = 'gemini-3-pro-image-preview';

export const PROMPT_ENHANCERS = "high detail, ultra-realistic lighting, sharp focus, professional composition, masterpiece, best quality";
