# ExpenseTracker - Design Guidelines

## Brand Identity
**Purpose**: A modern expense tracking app that helps users master their money with intuitive budget management, expense tracking, and spending insights.

**Aesthetic Direction**: Dark, sophisticated financial app with a rich dark green palette. The design emphasizes clarity, trust, and financial empowerment with vibrant accent colors for categories and actions.

**Memorable Element**: The sleek dark green interface with bright green accents creates a premium, trustworthy feel. Circular progress indicators and colorful category icons make financial data approachable.

## Navigation Architecture
**Root Navigation**: Bottom Tab Bar (4 tabs)
- **Home** - Dashboard with spending overview, budget status, and recent transactions
- **Stats** - Analytics and spending trends with charts
- **Budget** - Budget management and category limits
- **Profile** - Settings, currency preferences, and account management

**Floating Action Button**: Large "+" button (centered on tab bar) for adding expenses

## Screen-by-Screen Specifications

### 1. Login/Signup Screen
- **Layout**: Full screen dark green gradient background
- **Components**: 
  - App logo with bar chart graphic at top
  - "Master Your Money" headline with "Money" in green
  - Toggle between Login/Sign Up tabs
  - Email and password input fields with dark backgrounds
  - Primary green "Log In" / "Sign Up" button
  - "Quick login with Face ID" option
  - Social login buttons (Google, Apple)
  - "Don't have an account? Sign up" link

### 2. Home (Dashboard)
- **Header**: User greeting with avatar, month selector dropdown, notification bell
- **Components**:
  - Total Spent card with remaining budget (green progress bar)
  - Spending Breakdown donut chart with category legend
  - Recent Transactions list with category icons

### 3. Transactions List
- **Header**: "Transactions" title with Filter button
- **Components**:
  - Search bar
  - Period filter tabs (Daily, Weekly, Monthly, Category)
  - Transaction cards grouped by date with category icons and amounts
  - Floating "+" FAB

### 4. Add Expense Modal
- **Header**: "ADD EXPENSE" with close button
- **Components**:
  - Large amount display with currency symbol
  - Category selector (horizontal scroll of icon buttons)
  - Date picker (defaults to "Today")
  - Note input field
  - Custom numeric keypad
  - "Save Expense" button

### 5. Stats/Analytics Screen
- **Header**: "Spending Trends" with calendar icon
- **Components**:
  - Total spent this month with comparison to last month
  - Monthly Activity bar chart
  - Top Categories list with progress bars
  - Export buttons (PDF, CSV)

### 6. Budget Screen
- **Header**: "October Budget" with Edit button
- **Components**:
  - Circular remaining budget indicator
  - Alert card for budget warnings
  - Category Breakdown with progress bars
  - "Set Budget" button

### 7. Profile Screen
- **Components**:
  - User avatar and name
  - Settings list: Currency, Dark Mode toggle, Notifications
  - App preferences
  - Logout button

## Color Palette
**Dark Mode (Primary)**:
- Background Root: #0D1F17 (deep dark green)
- Background Default: #142620 (card backgrounds)
- Background Secondary: #1A3228 (elevated cards)
- Background Tertiary: #1F3D2F (highest elevation)
- Primary/Accent: #4ADE80 (bright green)
- Text Primary: #FFFFFF
- Text Secondary: #8B9A8F
- Success: #4ADE80
- Error: #EF4444
- Warning: #F59E0B
- Income: #4ADE80

**Light Mode**:
- Background Root: #F5F7F6
- Background Default: #FFFFFF
- Background Secondary: #E8EBE9
- Background Tertiary: #D9DDDA
- Primary/Accent: #22C55E
- Text Primary: #0D1F17
- Text Secondary: #6B7B6E

**Category Colors**:
- Food: #F97316 (orange)
- Transport: #3B82F6 (blue)
- Shopping: #FBBF24 (yellow)
- Bills: #10B981 (teal)
- Entertainment: #A855F7 (purple)
- Healthcare: #EC4899 (pink)
- Housing: #6366F1 (indigo)
- Others: #94A3B8 (slate)

## Typography
- **Font**: System default
- **Scale**:
  - H1 (Large amounts): 40sp, Bold
  - H2 (Section titles): 20sp, SemiBold
  - H3 (Card titles): 18sp, SemiBold
  - Body: 16sp, Regular
  - Small: 14sp, Regular
  - Caption: 12sp, Regular

## Visual Design
- Card corner radius: 16dp
- Input corner radius: 12dp
- Button corner radius: 24dp (full rounded)
- Category icon containers: 48x48dp with 12dp radius
- Shadows: Minimal, use elevation through background colors
- Progress bars: 8dp height with rounded ends

## Currency Support
- USD ($)
- PKR (Rs)
- INR (₹)
- EUR (€)
- GBP (£)
- AED (د.إ)

## Assets to Generate
1. **icon.png** - Dark green background with stylized bar chart in bright green
2. **splash-icon.png** - Same as icon
