import { Platform } from "react-native";

export const Colors = {
  light: {
    text: "#0D1F17",
    textSecondary: "#6B7B6E",
    buttonText: "#FFFFFF",
    tabIconDefault: "#6B7B6E",
    tabIconSelected: "#22C55E",
    link: "#22C55E",
    primary: "#22C55E",
    backgroundRoot: "#F5F7F6",
    backgroundDefault: "#FFFFFF",
    backgroundSecondary: "#E8EBE9",
    backgroundTertiary: "#D9DDDA",
    inputBackground: "#E8EBE9",
    border: "#D9DDDA",
    success: "#22C55E",
    error: "#EF4444",
    warning: "#F59E0B",
    income: "#22C55E",
    expense: "#EF4444",
  },
  dark: {
    text: "#FFFFFF",
    textSecondary: "#8B9A8F",
    buttonText: "#0D1F17",
    tabIconDefault: "#8B9A8F",
    tabIconSelected: "#4ADE80",
    link: "#4ADE80",
    primary: "#4ADE80",
    backgroundRoot: "#0D1F17",
    backgroundDefault: "#142620",
    backgroundSecondary: "#1A3228",
    backgroundTertiary: "#1F3D2F",
    inputBackground: "#1A3228",
    border: "#1F3D2F",
    success: "#4ADE80",
    error: "#EF4444",
    warning: "#F59E0B",
    income: "#4ADE80",
    expense: "#EF4444",
  },
};

export const CategoryColors = {
  food: "#F97316",
  transport: "#3B82F6",
  shopping: "#FBBF24",
  bills: "#10B981",
  entertainment: "#A855F7",
  healthcare: "#EC4899",
  housing: "#6366F1",
  others: "#94A3B8",
};

export const Currencies = [
  { code: "USD", symbol: "$", name: "US Dollar" },
  { code: "PKR", symbol: "Rs", name: "Pakistani Rupee" },
  { code: "INR", symbol: "₹", name: "Indian Rupee" },
  { code: "EUR", symbol: "€", name: "Euro" },
  { code: "GBP", symbol: "£", name: "British Pound" },
  { code: "AED", symbol: "د.إ", name: "UAE Dirham" },
];

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  "2xl": 24,
  "3xl": 32,
  "4xl": 40,
  "5xl": 48,
  inputHeight: 52,
  buttonHeight: 56,
};

export const BorderRadius = {
  xs: 8,
  sm: 12,
  md: 16,
  lg: 20,
  xl: 24,
  "2xl": 32,
  "3xl": 40,
  full: 9999,
};

export const Typography = {
  h1: {
    fontSize: 40,
    lineHeight: 48,
    fontWeight: "700" as const,
  },
  h2: {
    fontSize: 28,
    lineHeight: 36,
    fontWeight: "700" as const,
  },
  h3: {
    fontSize: 20,
    lineHeight: 28,
    fontWeight: "600" as const,
  },
  h4: {
    fontSize: 18,
    lineHeight: 26,
    fontWeight: "600" as const,
  },
  body: {
    fontSize: 16,
    lineHeight: 24,
    fontWeight: "400" as const,
  },
  small: {
    fontSize: 14,
    lineHeight: 20,
    fontWeight: "400" as const,
  },
  caption: {
    fontSize: 12,
    lineHeight: 16,
    fontWeight: "400" as const,
  },
  link: {
    fontSize: 16,
    lineHeight: 24,
    fontWeight: "500" as const,
  },
};

export const Fonts = Platform.select({
  ios: {
    sans: "system-ui",
    serif: "ui-serif",
    rounded: "ui-rounded",
    mono: "ui-monospace",
  },
  default: {
    sans: "normal",
    serif: "serif",
    rounded: "normal",
    mono: "monospace",
  },
  web: {
    sans: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
    serif: "Georgia, 'Times New Roman', serif",
    rounded:
      "'SF Pro Rounded', 'Hiragino Maru Gothic ProN', Meiryo, 'MS PGothic', sans-serif",
    mono: "SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace",
  },
});
